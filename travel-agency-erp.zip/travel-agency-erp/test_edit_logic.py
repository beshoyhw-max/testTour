import sys
import os
import pandas as pd
from datetime import datetime
sys.path.append(os.getcwd())
from modules.data_manager import DataManager

dm = DataManager()
print(">>> Testing Edit Quote Logic...")

# 1. Create a Quote
qid = dm.generate_id("ORDER_HEADER")
print(f"1. Creating Quote {qid}...")
header = {
    "order_id": qid,
    "customer_id": "CUST-TEST-001",
    "status": "Quote",
    "total_revenue": 100.0,
    "notes": "Original Note"
}
dm.add_record("ORDER_HEADER", header)
# Original Item
dm.add_record("ORDER_ITEM", {
    "order_id": qid, 
    "service_id": "SVC-OLD", 
    "quantity": 1, 
    "selling_price": 100.0,
    "day_number": 1,
    "start_time": "10:00"
})

# 2. Simulate "Edit" - Delete Old items, Update Header, Add New Items
print("2. simulating Update (Edit)...")
# Delete old items
old_items = dm.load_data("ORDER_ITEM")
new_items = old_items[old_items['order_id'] != qid]
dm.save_data("ORDER_ITEM", new_items)

# Update Header
dm.update_record("ORDER_HEADER", qid, {"notes": "Updated Note"})

# Add New Item
dm.add_record("ORDER_ITEM", {
    "order_id": qid, 
    "service_id": "SVC-NEW", 
    "quantity": 2, 
    "selling_price": 50.0,
    "day_number": 2,
    "start_time": "14:00"
})

# 3. Verify
print("3. Verifying...")
final_items = dm.load_data("ORDER_ITEM")
my_items = final_items[final_items['order_id'] == qid]
final_header = dm.load_data("ORDER_HEADER")
my_head = final_header[final_header['order_id'] == qid].iloc[0]

if len(my_items) == 1 and my_items.iloc[0]['service_id'] == "SVC-NEW":
    print("   [OK] Items updated correctly (Old removed, New added).")
else:
    print(f"   [FAIL] Item mismatch. Found: {my_items.to_dict('records')}")

if my_head['notes'] == "Updated Note":
    print("   [OK] Header updated correctly.")
else:
    print(f"   [FAIL] Header mismatch: {my_head['notes']}")

print("[SUCCESS] Edit Logic Verified.\n")
