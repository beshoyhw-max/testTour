# 📖 Travel Agency ERP System - User Guide

**Version:** 2.0 Production  
**Last Updated:** January 2026

---

## Table of Contents

1. [Introduction](#introduction)
2. [Getting Started](#getting-started)
3. [Dashboard Overview](#dashboard-overview)
4. [Order Management](#order-management)
5. [Services & Products](#services--products)
6. [Financial Reports](#financial-reports)
7. [Settings & CRM](#settings--crm)
8. [Customer Portal](#customer-portal)
9. [Data Management](#data-management)
10. [Troubleshooting](#troubleshooting)

---

## Introduction

Welcome to the **Travel Agency ERP System** - a comprehensive enterprise resource planning solution designed specifically for travel agencies. This system helps you manage:

- ✈️ **Orders & Bookings** - Create quotes, manage orders, track payments
- 🛍️ **Services & Products** - Maintain your service catalog with pricing
- 👥 **Customer Relationships** - Full CRM with customer history
- 🏢 **Vendor Management** - Track suppliers and partners
- 📊 **Financial Intelligence** - Reports, KPIs, and analytics
- 📄 **Document Generation** - Invoices and itinerary PDFs
- 👋 **Customer Self-Service** - Portal for customers to view their trips

### System Architecture

The system is built with:
- **Frontend:** Streamlit (Python web framework)
- **Database:** Local Excel files (easy to backup and migrate)
- **Reports:** Interactive Plotly charts
- **Documents:** PDF generation via FPDF

---

## Getting Started

### Prerequisites

- Python 3.8 or higher
- Required packages (see `requirements.txt`)

### Installation

1. **Install Dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Run the Application:**
   ```bash
   streamlit run main.py
   ```
   Or use the provided batch file:
   ```bash
   start.bat
   ```

3. **Access the System:**
   Open your browser and navigate to `http://localhost:8501`

### First-Time Setup

When you first run the system, it will automatically:
- Create the `data/` directory
- Initialize empty Excel database files with proper schemas
- Set up all required tables (Customers, Vendors, Services, Orders, etc.)

---

## Dashboard Overview

The main dashboard (`main.py`) provides a bird's-eye view of your business:

### Key Performance Indicators (KPIs)

| Metric | Description |
|--------|-------------|
| **Total Revenue** | Sum of all order revenue (YTD) |
| **Net Profit** | Total profit across all orders |
| **Active Orders** | Count of orders with "Confirmed" status |
| **Total Customers** | Number of customers in your CRM |

### Performance Chart

The dashboard displays a **Monthly Profit Chart** showing revenue and profit trends over time.

### Quick Actions

Access frequently used functions directly from the dashboard:

| Action | Description |
|--------|-------------|
| ➕ **New Order** | Jump to order creation wizard |
| 👤 **Add Customer** | Open customer management |
| 🏨 **Manage Services** | Access service catalog |
| 📈 **View Reports** | Open financial reports |

### Recent Activity

Shows the 5 most recent orders with their status for quick reference.

---

## Order Management

**Navigation:** Sidebar → `📝 Orders`

The Order Management page is the heart of your operations, divided into two main sections:

### Tab 1: Create New Order (Order Wizard)

A 3-step wizard guides you through creating orders:

#### Step 1: Customer & Trip Details

| Field | Description |
|-------|-------------|
| **Select Customer** | Choose from existing customers (shows email & phone) |
| **Trip Start** | Start date of the trip |
| **Trip End** | End date of the trip |
| **Pax Count** | Number of travelers |

> 💡 **Tip:** If you don't see your customer, go to Settings → Customers to add them first.

#### Step 2: Add Services

This step has two sub-tabs:

##### 🛒 Individual Services

1. **Filter by City:** Select a city to filter available services
2. **Filter by Category:** Narrow down by type (Car, Hotel, Activity, Guide, Other)
3. **Choose Service:** Select from the filtered list (favorites marked with ⭐)
4. **Assign Vendor:** Select who will provide the service
5. **Set Pricing:**
   - **Qty:** Number of units
   - **Unit Cost:** Your cost from vendor
   - **Margin (%):** Your markup percentage
   - **Unit Price:** Automatically calculated selling price

###### Car Services - Special Features

When adding Car services, you get additional options:

- **📍 Itinerary Locations:** Multi-select pickup/dropoff points
- **📉 Distance Calculation:** Automatic distance estimation using GPS coordinates

###### Itinerary Details

- **Day #:** Which day of the trip (1, 2, 3, etc.)
- **Set Time:** Optional time for the service (checkbox to enable)

Click **"Add to Order"** to add the item to your cart.

##### 📦 Packages

Pre-defined bundles of services. Click **"Add Bundle"** to add all package items to your cart at once.

##### 🛒 Cart (Right Column)

Shows all added items:
- Sorted by Day/Time
- Click ❌ to remove items
- Shows location info for car services

#### Step 3: Review & Submit

Review all details before finalizing:

| Metric | Description |
|--------|-------------|
| **Total Revenue** | Sum of all item selling prices × quantities |
| **Total Profit** | Revenue minus costs |
| **Margin %** | Profit as percentage of revenue |

**Additional Fields:**
- **Initial Deposit:** Amount received upfront
- **Order Notes:** Special requests, flight details, dietary restrictions, etc.

**Actions:**
| Button | Description |
|--------|-------------|
| 💾 **Save as Quote** | Save for later (no financial tracking) |
| ✅ **CONFIRM ORDER** | Create a confirmed order with payment tracking |

---

### Tab 2: Manage Orders

View and manage all existing orders:

#### Filters

| Filter | Description |
|--------|-------------|
| **Search Order ID** | Find specific order by ID |
| **Status Filter** | Filter by: Confirmed, Pending, Completed, Cancelled, Quote |

#### Order Cards

Each order displays in an expandable card showing:
- Order ID
- Status (📜 Quote / 📝 Order)
- Total Revenue

**Expand to see:**

##### For Quotes Only:
- **🚀 Convert to Order** - Change quote to pending order
- **✏️ Edit Quote Items** - Modify services/items

##### For All Orders:

**Editable Fields:**
| Field | Description |
|-------|-------------|
| **Status** | Update order status |
| **Deposit Paid** | Record payments received |
| **Order Notes** | Update notes/remarks |

Click **"Save Changes"** to persist updates.

##### Action Buttons

| Action | Description |
|--------|-------------|
| 💰 **Add Payment** | Record additional payments |
| 🖨️ **Print View** | View order in print-friendly format |
| 📄 **Download Invoice** | Generate PDF (Detailed or Summary) |
| ©️ **Duplicate as Quote** | Create a copy as a new quote |

---

### Order Statuses

| Status | Description |
|--------|-------------|
| **Quote** | Not yet confirmed, no payment tracking |
| **Pending** | Converted from quote, awaiting confirmation |
| **Confirmed** | Active order, in progress |
| **Completed** | Trip finished |
| **Cancelled** | Order cancelled |

---

## Services & Products

**Navigation:** Sidebar → `🛍️ Services`

Manage your service catalog, locations, and packages across three tabs.

### Tab 1: Product/Service Catalog

#### Adding a New Service

Click **➕ Add New Service** and fill out:

| Field | Description |
|-------|-------------|
| **Service Name** | Display name of the service |
| **Type** | Category: Car, Hotel, Activity, Guide, Other |
| **Sub Service** | Sub-category (e.g., "Sedan", "Suite", "Walking Tour") |
| **City** | City where service is available |
| **Base Cost** | Your cost from vendor |
| **Default Margin** | Standard markup percentage |

#### Managing Services

The **Data Editor** provides a spreadsheet-like interface:

| Column | Description |
|--------|-------------|
| **ID** | System-generated (read-only) |
| **Name** | Editable service name |
| **Type** | Dropdown selection |
| **Sub Service** | Sub-category text |
| **Cost** | Base cost in dollars |
| **Sell Price** | Auto-calculated (read-only) |
| **⭐ Favorite** | Mark as favorite for quick access |

> 📝 **Note:** Click **"💾 Save Changes"** after editing to persist data.

#### Deleting Services

Expand **"Delete Options"** → Select service → Click **"Delete Selected Service"**

---

### Tab 2: Geo Locations

Manage geographical points for route planning and distance calculations.

#### Adding a Location

| Field | Description |
|-------|-------------|
| **City** | City name |
| **Attraction Name** | Point of interest name |
| **Latitude** | GPS latitude coordinate |
| **Longitude** | GPS longitude coordinate |

> 💡 **Tip:** These locations appear when adding Car services, enabling automatic distance calculation.

---

### Tab 3: Packages

Create pre-bundled service combinations for quick order entry.

#### Creating a Package

1. Enter **Package Name** and **Description**
2. **Select Services** to include (multi-select)
3. Set **Quantity** for each included service
4. Review **Calculated Total Value**
5. Optionally adjust the **Package Price**
6. Click **"💾 Save Package"**

#### Using Packages

In the order wizard, packages appear in the **📦 Packages** tab. Click **"Add Bundle"** to add all package items to your cart instantly.

---

## Financial Reports

**Navigation:** Sidebar → `📈 Finance`

Comprehensive financial analytics and reporting.

### Date Range Filter

Use the sidebar to filter all reports by trip start date range.

### KPI Dashboard

| Metric | Description |
|--------|-------------|
| **Total Revenue** | Gross sales in date range |
| **Net Profit** | Profit with margin percentage |
| **Orders Count** | Number of orders in range |
| **Accounts Receivable** | Outstanding balance due |

### Tab 1: Profitability

#### Monthly Revenue vs Profit Chart
Bar chart comparing monthly revenue and profit trends.

#### Order Status Breakdown
Pie chart showing distribution of order statuses.

---

### Tab 2: Customer Ranking

**Top 10 Customers by Revenue** - Table with progress bars showing revenue contribution per customer.

---

### Tab 3: Service Performance

#### Revenue by Service Type
Sunburst chart showing revenue breakdown by service category and individual services.

#### Service Performance Table
Detailed table with units sold and total revenue per service.

---

### Export Financial Report

Click **"📥 Export Financial Report"** to download filtered data as CSV.

---

## Settings & CRM

**Navigation:** Sidebar → `⚙️ Settings`

Manage customers, vendors, and system administration.

### Tab 1: Customers (CRM)

#### Adding a Customer

Click **➕ Add Customer** and fill out:

| Field | Description |
|-------|-------------|
| **Full Name** | Customer's full name |
| **Priority** | Standard, VIP, or Corporate |
| **Phone** | Contact phone number |
| **Email** | Email address |
| **WeChat ID** | WeChat contact (optional) |

#### Managing Customers

The **Data Editor** allows inline editing of:
- Name, Phone, Email, WeChat
- Priority tier (dropdown)
- View order count (read-only)

#### Customer History

Select a customer to view:

| Metric | Description |
|--------|-------------|
| **Lifetime Value (LTV)** | Total revenue from this customer |
| **Total Orders** | Number of confirmed orders |
| **Last Active** | Most recent trip date |

Plus a detailed table of all their orders.

---

### Tab 2: Vendors

#### Adding a Vendor

Click **➕ Add Vendor** and fill out:

| Field | Description |
|-------|-------------|
| **Entity Name** | Company/individual name |
| **Type** | Driver, Hotel, Agency, Guide, Other |
| **Contact Number** | Phone number |
| **Contact Person** | Name of contact |
| **Payment Terms** | e.g., "Net 30" |

#### Managing Vendors

Edit vendor details inline using the Data Editor.

---

### Tab 3: System Admin

#### Data Backup

Click **"Run Full Backup"** to create timestamped copies of all database tables.

Backups are saved to: `data/backups/`

Backup naming format: `{TABLE}_BACKUP_{YYYYMMDD_HHMMSS}.xlsx`

#### Data Export

1. Select table from dropdown
2. Click **"Prepare Export"**
3. Download as CSV

Available tables:
- CUSTOMER
- VENDOR
- SERVICE_PRODUCT
- LOCATION
- ORDER_HEADER
- ORDER_ITEM
- PACKAGE_DEF
- PACKAGE_ITEMS

---

## Customer Portal

**Navigation:** Sidebar → `👋 Customer Portal`

A self-service portal for customers to view their trip details.

### Accessing the Portal

Customers (or you on their behalf) can access by entering:
- **Order ID** (e.g., ORD-2026-001)

No password required - simple order-number access.

### Portal Features

Once logged in, customers see:

#### Trip Summary
| Information | Details |
|-------------|---------|
| **Trip Start** | Formatted start date |
| **Trip End** | Formatted end date |
| **Travelers** | Pax count |
| **Balance Due** | Outstanding amount |

#### 📅 Itinerary

Expandable day-by-day view showing:
- Day number and date
- Time and service name for each activity
- Quantity information

#### 📂 Documents & Actions

| Document | Description |
|----------|-------------|
| **Invoice PDF** | Download trip invoice |
| **Itinerary PDF** | Download formatted itinerary |

#### 📞 Support Information

Contact details for customer support.

#### Important Notes

Displays any notes attached to the order.

### Logout

Click **🔒 Logout** to return to the login screen.

---

## Data Management

### Database Structure

The system uses Excel files stored in the `data/` directory:

| File | Description |
|------|-------------|
| `CUSTOMER.xlsx` | Customer database |
| `VENDOR.xlsx` | Vendor/supplier database |
| `SERVICE_PRODUCT.xlsx` | Service catalog |
| `LOCATION.xlsx` | Geo locations for routing |
| `ORDER_HEADER.xlsx` | Order master records |
| `ORDER_ITEM.xlsx` | Order line items |
| `PACKAGE_DEF.xlsx` | Package definitions |
| `PACKAGE_ITEMS.xlsx` | Package contents |

### ID Generation

The system automatically generates readable IDs:

| Table | Format | Example |
|-------|--------|---------|
| Customers | CUS-XXX | CUS-001 |
| Vendors | VEN-XXX | VEN-001 |
| Services | SVC-XXX | SVC-001 |
| Orders | ORD-YYYY-XXX | ORD-2026-001 |
| Packages | PKG-XXX | PKG-001 |

### Backup Strategy

**Recommended:** Run backups daily or before major data changes.

1. Go to **Settings** → **System Admin**
2. Click **"Run Full Backup"**
3. Backups saved to `data/backups/`

### Data Recovery

To restore from backup:
1. Navigate to `data/backups/`
2. Find the desired backup file
3. Copy to `data/` directory
4. Rename to original table name (e.g., `CUSTOMER.xlsx`)
5. Restart the application

---

## Troubleshooting

### Common Issues

#### "No customers found"
**Solution:** Go to Settings → Customers → Add Customer before creating orders.

#### "No services available"
**Solution:** Go to Services → Add New Service to populate your catalog.

#### Order not saving
**Possible causes:**
- Excel file locked by another program
- Insufficient disk space
- Permission issues in data directory

**Solution:** Close any Excel instances, check disk space, and ensure write permissions.

#### Invoice/PDF download not working
**Solution:** Ensure `fpdf` package is installed: `pip install fpdf`

#### Charts not displaying
**Solution:** Ensure `plotly` package is installed: `pip install plotly`

### Getting Help

- **Technical Issues:** Check console output for error messages
- **Data Recovery:** Use backups from `data/backups/`
- **Feature Requests:** Document and prioritize for future development

---

## Keyboard Shortcuts & Tips

### Streamlit Tips

- **Refresh data:** Press `R` or click the refresh button
- **Wide mode:** Already enabled by default in this system
- **Theme:** Change via Settings menu (hamburger icon)

### Productivity Tips

1. **Use Favorites:** Mark frequently used services as ⭐ Favorite for faster access
2. **Create Packages:** Bundle common service combinations to speed up order entry
3. **Search First:** Use search fields to quickly find customers, services, or orders
4. **Duplicate Quotes:** Use "Duplicate as Quote" for similar trips
5. **Regular Backups:** Run backups before major data entry sessions

---

## Appendix

### Service Types

| Type | Description | Examples |
|------|-------------|----------|
| **Car** | Ground transportation | Airport transfer, full-day car, multi-point tour |
| **Hotel** | Accommodation | Room night, suite, boutique hotel |
| **Activity** | Tours & experiences | City tour, cooking class, show tickets |
| **Guide** | Guide services | Local guide, translator, escort |
| **Other** | Miscellaneous | Travel insurance, SIM card, visa service |

### Customer Priority Levels

| Level | Description |
|-------|-------------|
| **Standard** | Regular customers |
| **VIP** | High-value customers, priority service |
| **Corporate** | Business accounts, volume discounts |

### Vendor Types

| Type | Description |
|------|-------------|
| **Driver** | Car/transportation providers |
| **Hotel** | Accommodation providers |
| **Agency** | Partner travel agencies |
| **Guide** | Tour guides and translators |
| **Other** | Other service providers |

---

## Support

For system support, contact your system administrator.

**System Version:** 2.0 Production  
**Database:** Local Excel  
**Last Updated:** January 2026

---

*Thank you for using Travel Agency ERP System!* ✈️
