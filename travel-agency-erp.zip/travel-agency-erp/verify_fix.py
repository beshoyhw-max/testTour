import pandas as pd
from datetime import datetime
import sys
import os

# Add project root to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from modules.logistics import LogisticsManager

lm = LogisticsManager()
start_date = datetime.now()

# Create data with mixed types in start_time: str, nan, None
data = [
    {'day_number': 1, 'start_time': '10:00', 'name': 'Item 1'},
    {'day_number': 1, 'start_time': float('nan'), 'name': 'Item 2'},
    {'day_number': 1, 'start_time': '09:00', 'name': 'Item 3'},
    {'day_number': 1, 'name': 'Item 4'} # Missing start_time key
]
df = pd.DataFrame(data)

print("DataFrame content:")
print(df)
# Convert to dict manually to mimic what happens inside if not passing DF, 
# but the function handles DF.
# Note: to_dict('records') preserves NaNs as floats.

try:
    timeline = lm.generate_itinerary_timeline(start_date, df)
    print("\nSuccess! Generated timeline:")
    for day in timeline:
        print(f"Day {day['day']}:")
        for item in day['items']:
            # Handle nan in print
            st = item.get('start_time')
            print(f"  - {st} (Type: {type(st)}) - {item.get('name')}")
except Exception as e:
    print(f"\nFAILED with error: {e}")
    # Print traceback
    import traceback
    traceback.print_exc()
    sys.exit(1)
