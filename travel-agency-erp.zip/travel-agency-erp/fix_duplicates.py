
import pandas as pd
import sys
import os

# Add parent dir to path to import modules
sys.path.append(os.getcwd())
from modules.data_manager import DataManager

def fix_duplicates():
    dm = DataManager()
    df = dm.load_data("ORDER_HEADER")
    
    if df.empty:
        print("No orders to check.")
        return

    # Identify duplicates
    counts = df['order_id'].value_counts()
    duplicates = counts[counts > 1].index.tolist()
    
    if not duplicates:
        print("No duplicates found.")
        return
        
    print(f"Found duplicates: {duplicates}")
    
    # Iterate and fix
    seen_ids = {}
    new_rows = []
    
    for _, row in df.iterrows():
        oid = row['order_id']
        if oid in seen_ids:
            # Generate new ID
            # Simple fix: append index or increment
            seen_ids[oid] += 1
            new_id = f"{oid}-{seen_ids[oid]}" 
            row['order_id'] = new_id
            print(f"Fixed duplicate: {oid} -> {new_id}")
        else:
            seen_ids[oid] = 0
            
        new_rows.append(row)
        
    new_df = pd.DataFrame(new_rows)
    
    # Save back
    if dm.save_data("ORDER_HEADER", new_df):
        print("✅ Fixed duplicates and saved file.")
    else:
        print("❌ Failed to save fixed file.")

if __name__ == "__main__":
    fix_duplicates()
