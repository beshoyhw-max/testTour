import sys
import os
import pandas as pd
from datetime import datetime
sys.path.append(os.getcwd())

from modules.data_manager import DataManager
from modules.logistics import LogisticsManager

dm = DataManager()
lm = LogisticsManager()

print(">>> Starting End-to-End Test Suite...\n")

# --- 1. SETUP: Create Dummy Customer & Service ---
print("[1] Setting up Test Data...")
cust_id = "CUST-TEST-001"
cust_data = {
    "customer_id": cust_id,
    "name": "Test User",
    "phone": "555-0199",
    "email": "test@example.com",
    "wechat_id": "wx_test",
    "priority": "High",
    "channel": "Direct",
    "number_of_orders": 0
}
# Clean up old test data if exists
dm.delete_record("CUSTOMER", cust_id)
dm.add_record("CUSTOMER", cust_data)

svc_id = "SVC-TEST-001"
svc_data = {
    "service_id": svc_id,
    "service_name": "Test Hotel",
    "service_type": "Hotel",
    "default_base_cost": 100.0,
    "default_profit_margin_percent": 20.0,
    "standard_selling_price": 120.0,
    "is_favorite": True,
    "city": "Test City"
}
# Delete generic doesn't work well for non-standard PKs if I implemented strict checks, 
# but DataManager generic delete uses 1st column. Let's assume it works or just overwrite.
# Actually add_record appends, so duplicates might happen if not careful.
# For this test we will just append and ignore dups for services/customers as they are lookups.
# A better way is to check if exists.
all_svcs = dm.load_data("SERVICE_PRODUCT")
if svc_id not in all_svcs['service_id'].values:
    dm.add_record("SERVICE_PRODUCT", svc_data)
print("   [OK] Customer & Service ready.\n")


# --- 2. PHASE 3: PACKAGE CREATOR ---
print("[2] Testing Package Creation (Phase 3)...")
pkg_id = dm.generate_id("PACKAGE_DEF")
pkg_def = {
    "package_id": pkg_id,
    "package_name": "Test Weekend Bundle",
    "total_price": 200.0,
    "description": "A test bundle"
}
dm.add_record("PACKAGE_DEF", pkg_def)

pkg_item = {
    "package_id": pkg_id,
    "service_id": svc_id,
    "quantity": 2
}
dm.add_record("PACKAGE_ITEMS", pkg_item)

# Verify
pkgs = dm.load_data("PACKAGE_DEF")
if not pkgs[pkgs['package_id'] == pkg_id].empty:
    print(f"   [OK] Package {pkg_id} created.")
else:
    print("   [FAIL] Package creation failed.")
print("")


# --- 3. PHASE 2: QUOTE & DUPLICATION ---
print("[3] Testing Order Logic (Phase 2)...")

# Create Quote
quote_id = dm.generate_id("ORDER_HEADER")
quote_header = {
    "order_id": quote_id,
    "customer_id": cust_id,
    "trip_start_date": datetime.now(),
    "trip_end_date": datetime.now(),
    "pax_count": 1,
    "status": "Quote",
    "total_cost": 200.0,
    "total_revenue": 240.0,
    "total_profit": 40.0,
    "deposit_paid": 0.0,
    "balance_due": 240.0,
    "notes": "Test Quote"
}
dm.add_record("ORDER_HEADER", quote_header)

# Create Item (Day 1)
quote_item = {
    "order_id": quote_id,
    "service_id": svc_id,
    "quantity": 2,
    "actual_cost": 100.0,
    "profit_margin_percent": 20.0,
    "selling_price": 120.0,
    "day_number": 1,
    "start_time": "10:00"
}
dm.add_record("ORDER_ITEM", quote_item)
print(f"   [OK] Quote {quote_id} created.")

# Duplicate
success, new_oid = dm.duplicate_order(quote_id)
if success:
    print(f"   [OK] Duplicated to {new_oid}.")
    # Verify Dupe is Quote
    orders = dm.load_data("ORDER_HEADER")
    dupe_row = orders[orders['order_id'] == new_oid].iloc[0]
    if dupe_row['status'] == 'Quote':
        print("   [OK] Duplicate status is 'Quote'.")
    else:
        print(f"   [FAIL] Duplicate status is {dupe_row['status']}")
else:
    print(f"   [FAIL] Duplication failed: {new_oid}")

# Convert Original to Order
dm.update_record("ORDER_HEADER", quote_id, {"status": "Pending"})
print(f"   [OK] Converted {quote_id} to Pending Order.\n")


# --- 4. PHASE 1: FINANCIALS ---
print("[4] Testing Financials (Phase 1)...")
# Add Payment
dm.update_record("ORDER_HEADER", quote_id, {"deposit_paid": 100.0, "balance_due": 140.0})

# Verify in Data
orders = dm.load_data("ORDER_HEADER")
row = orders[orders['order_id'] == quote_id].iloc[0]
if float(row['deposit_paid']) == 100.0:
    print("   [OK] Payment recorded (Deposit: $100).")
else:
    print(f"   [FAIL] Payment mismatch: {row['deposit_paid']}")
print("")


# --- 5. PHASE 3: PORTAL ACCESS ---
print("[5] Testing Portal Access (Phase 3)...")
# Mock Portal Login Logic
orders = dm.load_data("ORDER_HEADER")
trip = orders[orders['order_id'] == quote_id]

if not trip.empty:
    cid = trip.iloc[0]['customer_id']
    cust = dm.load_data("CUSTOMER")
    c_row = cust[cust['customer_id'] == cid].iloc[0]
    
    # Test Matches
    email_match = c_row['email'] == "test@example.com"
    phone_match = c_row['phone'] == "555-0199"
    
    if email_match and phone_match:
        print("   [OK] Portal Login Verified (Email & Phone match).")
    else:
        print("   [FAIL] Portal Validation Logic Failed.")
else:
    print("   [FAIL] Order for Portal test not found.")

print("\n[SUCCESS] Test Suite Completed.")
