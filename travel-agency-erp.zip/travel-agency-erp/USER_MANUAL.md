



# ✈️ Travel Agency System - User Manual

**Welcome!** This guide will help you use your Travel Agency System to manage trips, customers, and finances. No technical knowledge required!

---

## 🏠 Your Dashboard

When you open the system, you land on the **Dashboard**. Think of this as your command center.

- **Top Row Numbers**: At a glance, see your Total Revenue, Net Profit, how many Active Orders you have, and your Total Customer count.
- **Charts**: A visual graph showing your monthly profit trends.
- **Quick Actions**: Big buttons to verify quickly jump to common tasks like **New Order** or **Add Customer**.
- **Recent Activity**: A list of the latest orders so you can catch up on what's new.

---

## 👥 Managing Customers

Before you can book a trip, you need a customer profile.

### How to Add a New Customer
1. Go to **Settings** in the side menu.
2. Click the **Customers** tab.
3. Click the **➕ Add Customer** button.
4. Fill in their Name, Email, Phone, and Priority Level (Standard, VIP, or Corporate).
5. Click **Save Customer**.

### Viewing Customer History
Want to see how much a client has spent with you?
1. Stay in the **Customers** tab in Settings.
2. Scroll down to **Customer History**.
3. Select a name from the dropdown list.
4. You'll see their "Lifetime Value" (total spending) and a list of all their past trips.

---

## 📝 Creating a New Order

This is where you build trips. Go to **Orders** in the side menu.

### Step 1: Who & When
- Select your **Customer** from the list.
- Pick the **Trip Start** and **Tip End** dates.
- Enter how many people are traveling (**Pax Count**).
- Click **Next**.

### Step 2: Adding Services (The Fun Part!)
You can add individual items or full packages.

**To add a single service (like a hotel or tour):**
1. **Filter** by City or Category (e.g., "Hotel" or "Activity") to find what you need easier.
2. **Select the Service** from the dropdown. 
   - *Tip: Favorites are marked with a star ⭐.*
3. **Assign a Vendor** (who is providing this service?).
4. **Enter Price Details**:
   - **Cost**: What you pay the vendor.
   - **Margin**: Your profit percentage. The system calculates the selling price for you!
5. **Add Details**: Choose the Day Number and Time.
6. Click **Add to Order**.

**To add a Package:**
1. Switch to the **📦 Packages** tab.
2. Find a bundle you like and click **Add Bundle**. All items in that package will be added to your cart instantly!

### Step 3: Review & Finish
1. Check the **Cart** summary. Does everything look right?
2. You can add an **Initial Deposit** if the customer paid freely.
3. Add any **Notes** (dietary needs, flight numbers, etc.).
4. Click **✅ CONFIRM ORDER** to finalize it, or **💾 Save as Quote** if they haven't decided yet.

---

## 📂 Managing Existing Orders

Go to the **Manage Orders** tab on the Orders page.

### Searching
Use the **Search Box** to find an order ID, or use the **Status Filters** to see just "Confirmed" or "Pending" trips.

### What You Can Do
Click on any order to expand it. You can:
- **Change Status**: Mark a trip as "Completed" or "Cancelled".
- **Record Payments**: Click **💰 Add Payment** to log money received.
- **Print/Download**: 
  - Click **📄 Download Invoice** to get a professional PDF for your client.
  - Click **🖨️ Print View** for a simple layout to print.
- **Convert Quotes**: If you saved a Quote earlier, you'll see a **🚀 Convert to Order** button to make it official.

---

## 🛍️ Services & Products

Go to **Services** in the side menu to manage what you sell.

### Adding Things to Sell
1. Click **➕ Add New Service**.
2. Enter the details: Name, Type (Car, Hotel, etc.), City, and your Base Cost.
3. Click **Save**.

### Creating Packages
Want to sell a "Weekend Getaway" bundle?
1. Go to the **Packages** tab.
2. Give it a name and description.
3. Select which services go inside it (e.g., "City Hotel" + "City Tour").
4. The system adds up the price, but you can set a special "Bundle Price".
5. Save it. Now you can add this entire bundle to any order in one click!

---

## 📈 Financial Reports

Go to **Finance** to see how your business is doing.

- **Profitability**: Charts showing which months were your best.
- **Customer Ranking**: Who are your top spenders?
- **Service Performance**: Which tours or hotels are selling the most?

You can also click **📥 Export Financial Report** to get a spreadsheet file tailored for your accountant.

---

## 👋 Customer Portal

Your customers have their own special view!

- They can log in using just their **Order ID** (e.g., `ORD-2026-001`). No passwords to remember.
- Inside, they see their **Itinerary**, **Balance Due**, and can download their own **Invoices** and **Trip Documents**.
- It's a great way to let them check details without calling you!

---

## ❓ Common Questions

**How do I find a lost order?**
Go to the **Orders** page, click **Manage Orders**, and make sure all filters are unchecked. Search by the customer's name or Order ID.

**How do I calculate distance for a car transfer?**
When adding a "Car" service in a New Order, select your **Itinerary Locations** (pickup/dropoff). The system will automatically calculate the kilometers between them!

**Can I duplicate an old trip?**
Yes! Find the old order in **Manage Orders**, expand it, and click **©️ Duplicate as Quote**. It saves you from typing everything again!

---

*Enjoy using your system!*
