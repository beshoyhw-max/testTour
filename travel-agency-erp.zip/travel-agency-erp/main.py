import streamlit as st
import pandas as pd
import sys
import os
import plotly.express as px

# --- PATH CONFIGURATION ---
sys.path.append(os.path.abspath(os.path.dirname(__file__)))

from modules.data_manager import DataManager
from modules.financials import FinancialAnalyzer

# Page Config
st.set_page_config(
    page_title="Travel ERP",
    page_icon="✈️",
    layout="wide",
    initial_sidebar_state="expanded"
)

from modules.ui_components import render_header, format_compact

def main():
    render_header("Travel Agency ERP System", "✈️", "Production Dashboard")
    
    # Initialize Core Modules
    dm = DataManager()
    fin = FinancialAnalyzer(dm)
    
    # Cached loader for performance
    @st.cache_data(ttl=60)
    def load_cached(table_name):
        return dm.load_data(table_name)
    
    # Load Data for Dashboard
    orders = dm.load_data("ORDER_HEADER")
    customers = dm.load_data("CUSTOMER")
    
    # KPIs
    kpis = fin.get_kpis()
    
    # Top Row Metrics
    c1, c2, c3, c4 = st.columns(4)
    with c1:
        st.metric("Total Revenue", format_compact(kpis['revenue']), delta="YTD")
    with c2:
        st.metric("Net Profit", format_compact(kpis['profit']), delta_color="normal")
    with c3:
        st.metric("Active Orders", len(orders[orders['status'] == 'Confirmed']), delta="In Progress")
    with c4:
        st.metric("Total Customers", len(customers), delta="CRM")

    st.divider()
    
    # Quick Actions & Main Content
    col_main, col_side = st.columns([3, 1])
    
    with col_main:
        st.subheader("📊 Performance Overview")
        chart = fin.get_monthly_profit_chart()
        if chart:
            st.plotly_chart(chart, use_container_width=True)
        else:
            st.info("No financial data available to display charts.")
        
        # --- NEW: Dashboard Widgets ---
        st.divider()
        w1, w2, w3 = st.columns(3)
        
        # Widget 1: Upcoming Trips (Next 7 Days)
        with w1:
            st.markdown("### 🗓️ Upcoming Trips")
            if not orders.empty:
                from datetime import datetime, timedelta
                orders['trip_start_date'] = pd.to_datetime(orders['trip_start_date'])
                today = pd.Timestamp.now().normalize()
                week_ahead = today + timedelta(days=7)
                
                upcoming = orders[
                    (orders['trip_start_date'] >= today) & 
                    (orders['trip_start_date'] <= week_ahead) &
                    (orders['status'].isin(['Confirmed', 'Pending']))
                ].sort_values('trip_start_date')
                
                if not upcoming.empty:
                    for _, trip in upcoming.head(5).iterrows():
                        trip_date = trip['trip_start_date'].strftime('%b %d')
                        st.caption(f"**{trip_date}** - {trip['order_id']} ({trip['status']})")
                else:
                    st.caption("No trips in next 7 days")
            else:
                st.caption("No orders yet")
        
        # Widget 2: Balance Aging
        with w2:
            st.markdown("### 💰 Receivables Aging")
            if not orders.empty:
                # Filter non-quotes with balance due
                active = orders[(orders['status'] != 'Quote') & (orders['status'] != 'Cancelled')].copy()
                active['balance_due'] = pd.to_numeric(active['balance_due'], errors='coerce').fillna(0)
                active = active[active['balance_due'] > 0]
                
                if not active.empty:
                    active['trip_start_date'] = pd.to_datetime(active['trip_start_date'])
                    today = pd.Timestamp.now().normalize()
                    active['days_overdue'] = (today - active['trip_start_date']).dt.days
                    
                    # Buckets
                    current = active[active['days_overdue'] <= 0]['balance_due'].sum()
                    bucket_30 = active[(active['days_overdue'] > 0) & (active['days_overdue'] <= 30)]['balance_due'].sum()
                    bucket_60 = active[(active['days_overdue'] > 30) & (active['days_overdue'] <= 60)]['balance_due'].sum()
                    bucket_90 = active[active['days_overdue'] > 60]['balance_due'].sum()
                    
                    st.caption(f"🟢 Current: **LE {current:,.0f}**")
                    st.caption(f"🟡 1-30 days: **LE {bucket_30:,.0f}**")
                    st.caption(f"🟠 31-60 days: **LE {bucket_60:,.0f}**")
                    st.caption(f"🔴 60+ days: **LE {bucket_90:,.0f}**")
                else:
                    st.caption("No outstanding balances")
            else:
                st.caption("No orders yet")
        
        # Widget 3: Customer Channel Breakdown
        with w3:
            st.markdown("### 📣 Acquisition Channels")
            if not customers.empty and 'channel' in customers.columns:
                channel_counts = customers['channel'].value_counts().reset_index()
                channel_counts.columns = ['channel', 'count']
                
                if not channel_counts.empty:
                    fig = px.pie(
                        channel_counts, 
                        values='count', 
                        names='channel',
                        hole=0.4,
                        color_discrete_sequence=px.colors.qualitative.Set3
                    )
                    fig.update_layout(
                        showlegend=True,
                        margin=dict(t=0, b=0, l=0, r=0),
                        height=180
                    )
                    st.plotly_chart(fig, use_container_width=True)
                else:
                    st.caption("No channel data")
            else:
                st.caption("No customer data")
            
    with col_side:
        st.subheader("⚡ Quick Actions")
        with st.container(border=True):
            st.page_link("pages/1_Orders.py", label="New Order", icon="➕")
            st.page_link("pages/4_Settings.py", label="Add Customer", icon="👤")
            st.page_link("pages/2_Services.py", label="Manage Services", icon="🏨")
            st.page_link("pages/3_Finance.py", label="View Reports", icon="📈")
            
        st.subheader("🔔 Recent Activity")
        if not orders.empty:
            recent = orders.sort_values("order_id", ascending=False).head(5)
            for _, row in recent.iterrows():
                st.info(f"Order #{row['order_id']} - {row['status']}", icon="📝")
        else:
            st.text("No recent activity.")
            
    # Footer
    st.markdown("---")
    st.caption(f"System Online | Database: Local Excel | v2.1 Production Tier")

if __name__ == "__main__":
    main()
