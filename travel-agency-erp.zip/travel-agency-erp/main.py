import streamlit as st
import pandas as pd
import sys
import os
import plotly.express as px

# --- PATH CONFIGURATION ---
sys.path.append(os.path.abspath(os.path.dirname(__file__)))

from modules.data_manager import DataManager
from modules.financials import FinancialAnalyzer

# Page Config
st.set_page_config(
    page_title="Travel ERP",
    page_icon="✈️",
    layout="wide",
    initial_sidebar_state="expanded"
)

from modules.ui_components import render_header

def main():
    render_header("Travel Agency ERP System", "✈️", "Production Dashboard")
    
    # Initialize Core Modules
    dm = DataManager()
    fin = FinancialAnalyzer(dm)
    
    # Load Data for Dashboard
    orders = dm.load_data("ORDER_HEADER")
    customers = dm.load_data("CUSTOMER")
    
    # KPIs
    kpis = fin.get_kpis()
    
    # Top Row Metrics
    c1, c2, c3, c4 = st.columns(4)
    with c1:
        st.metric("Total Revenue", f"${kpis['revenue']:,.2f}", delta="YTD")
    with c2:
        st.metric("Net Profit", f"${kpis['profit']:,.2f}", delta_color="normal")
    with c3:
        st.metric("Active Orders", len(orders[orders['status'] == 'Confirmed']), delta="In Progress")
    with c4:
        st.metric("Total Customers", len(customers), delta="CRM")

    st.divider()
    
    # Quick Actions & Main Content
    col_main, col_side = st.columns([3, 1])
    
    with col_main:
        st.subheader("📊 Performance Overview")
        chart = fin.get_monthly_profit_chart()
        if chart:
            st.plotly_chart(chart, width='stretch')
        else:
            st.info("No financial data available to display charts.")
            
    with col_side:
        st.subheader("⚡ Quick Actions")
        with st.container(border=True):
            st.page_link("pages/1_Orders.py", label="New Order", icon="➕")
            st.page_link("pages/4_Settings.py", label="Add Customer", icon="👤")
            st.page_link("pages/2_Services.py", label="Manage Services", icon="🏨")
            st.page_link("pages/3_Finance.py", label="View Reports", icon="📈")
            
        st.subheader("🔔 Recent Activity")
        if not orders.empty:
            recent = orders.sort_values("order_id", ascending=False).head(5)
            for _, row in recent.iterrows():
                st.info(f"Order #{row['order_id']} - {row['status']}", icon="📝")
        else:
            st.text("No recent activity.")
            
    # Footer
    st.markdown("---")
    st.caption(f"System Online | Database: Local Excel | v2.0 Production Tier")

if __name__ == "__main__":
    main()
