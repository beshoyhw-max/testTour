import sys
import os
import pandas as pd
from datetime import datetime

# Setup path
sys.path.append(os.getcwd())

from modules.data_manager import DataManager
from modules.itinerary_exporter import ItineraryExporter
from modules.invoice_generator import InvoiceGenerator

print('--- verifing data_manager ---')
dm = DataManager()
assert 'ITINERARY' in dm.SCHEMAS
assert 'CURRENCY_RATE' in dm.SCHEMAS
print('Schemas: OK')

print('--- verifying itinerary_exporter ---')
ie = ItineraryExporter()
df = pd.DataFrame([{
    'entry_id': 'ITN-001', 'order_id': 'ORD-1', 'date': '2026-02-01', 
    'start_time': '09:00', 'end_time': '10:00', 'city_route': 'Test City', 
    'activity': 'Test Activity', 'notes': 'Test Note', 'accommodation': 'Test Hotel'
}])
excel_bytes = ie.generate_excel(df)
assert excel_bytes is not None
print('Excel Generation: OK')

print('--- verifying invoice_generator ---')
ig = InvoiceGenerator()
# Mock data
order_items = pd.DataFrame([{
    'service_id': 'SVC-001', 'selling_price': 100, 'quantity': 1, 'service_name': 'Test'
}])
pdf_bytes = ig.generate_pdf('ORD-1', {'name': 'Test'}, {}, order_items, currency_code='USD', exchange_rate=50.0)
assert pdf_bytes is not None
print('PDF Generation: OK')

print('ALL TESTS PASSED')
