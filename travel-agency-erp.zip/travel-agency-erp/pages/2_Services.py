import streamlit as st
import sys
import os
import pandas as pd
import time

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from modules.data_manager import DataManager
from modules.validators import validate_service

# Page Config
st.set_page_config(page_title="Services Database", layout="wide", page_icon="🛍️")

# Initialize Manager
dm = DataManager()

# --- HELPER FUNCTIONS ---
def success_toast(msg):
    st.toast(msg, icon="✅")
    time.sleep(1)

def error_toast(msg):
    st.toast(msg, icon="❌")

def delete_service_handler(id_to_delete):
    if dm.delete_record("SERVICE_PRODUCT", id_to_delete):
        success_toast("Service Deleted Successfully")
        st.rerun()
    else:
        error_toast("Failed to delete service")

def delete_location_handler(id_to_delete):
    if dm.delete_record("LOCATION", id_to_delete):
        success_toast("Location Deleted Successfully")
        st.rerun()
    else:
        error_toast("Failed to delete location")

from modules.ui_components import render_header

# --- MAIN PAGE ---
render_header("Services & Locations", "🛍️")

tab1, tab2, tab3 = st.tabs(["🧩 Product/Service Catalog", "📍 Geo Locations", "📦 Packages"])

# ==========================
# TAB 1: SERVICE PRODUCTS
# ==========================
with tab1:
    # Top Bar: Search & Add
    col1, col2 = st.columns([3, 1])
    with col1:
        search_query = st.text_input("🔍 Search Services", placeholder="Search by Name, City, or Type...")
    
    with col2:
        add_btn = st.button("➕ Add New Service", width='stretch')

    # Add Service Form (Expander)
    if add_btn or st.session_state.get("show_add_service", False):
        st.session_state.show_add_service = True
        with st.expander("📝 New Service Details", expanded=True):
            with st.form("new_svc_form"):
                c1, c2 = st.columns(2)
                s_name = c1.text_input("Service Name")
                s_type = c2.selectbox("Type", ["Car", "Hotel", "Activity", "Guide", "Other"])
                
                c3, c4 = st.columns(2)
                s_sub = c3.text_input("Sub Service (e.g. Sedan, Suite)")
                s_city = c4.text_input("City")
                
                c5, c6 = st.columns(2)
                s_cost = c5.number_input("Base Cost ($)", min_value=0.0, step=10.0)
                s_margin = c6.slider("Default Margin (%)", 0, 100, 20)
                
                if st.form_submit_button("✅ Save Service"):
                    new_record = {
                        "service_name": s_name,
                        "service_type": s_type,
                        "types": s_sub,
                        "city": s_city,
                        "default_base_cost": s_cost,
                        "default_profit_margin_percent": s_margin,
                        "standard_selling_price": s_cost * (1 + s_margin/100)
                    }
                    
                    is_valid, err_msg = validate_service(new_record)
                    if is_valid:
                        if dm.add_record("SERVICE_PRODUCT", new_record):
                            success_toast("Service Added!")
                            st.session_state.show_add_service = False
                            st.rerun()
                        else:
                            error_toast("Database Error")
                    else:
                        error_toast(err_msg)

    st.divider()

    # Data Display
    if search_query:
        df_svc = dm.search_records("SERVICE_PRODUCT", search_query)
    else:
        df_svc = dm.load_data("SERVICE_PRODUCT")

    if not df_svc.empty:
        # Ensure is_favorite is boolean for the checkbox column which fixes the StreamlitAPIException
        if 'is_favorite' in df_svc.columns:
            df_svc['is_favorite'] = df_svc['is_favorite'].fillna(0).astype(bool)
        # Display as a styled dataframe with limited height or pagination could be better, 
        # but for CRUD, data_editor is most practical if we handle the state correctly.
        # Alternatively, for "Production" feel, we can use a grid of cards or a clean table with actions.
        # Let's use a Data Editor for bulk edits, but protected.
        
        st.subheader(f"All Services ({len(df_svc)})")
        
        # Persistent Data Editor
        edited_df = st.data_editor(
            df_svc,
            column_config={
                "service_id": st.column_config.TextColumn("ID", disabled=True),
                "service_name": "Name",
                "service_type": st.column_config.SelectboxColumn("Type", options=["Car", "Hotel", "Activity", "Guide", "Other"]),
                "types": st.column_config.TextColumn("Sub Service"),
                "default_base_cost": st.column_config.NumberColumn("Cost ($)", format="$%.2f"),
                "default_base_cost": st.column_config.NumberColumn("Cost ($)", format="$%.2f"),
                "standard_selling_price": st.column_config.NumberColumn("Sell Price ($)", format="$%.2f", disabled=True), # Auto-calc needed
                "is_favorite": st.column_config.CheckboxColumn("⭐ Favorite", default=False),
            },
            hide_index=True,
            width='stretch',
            num_rows="fixed",
            key="svc_editor"
        )
        
        # Save Changes Button
        if st.button("💾 Save Changes"):
            # Identify changes (simplified: just save all)
            # Re-calculate selling price for updated rows
            edited_df['standard_selling_price'] = edited_df['default_base_cost'] * (1 + edited_df['default_profit_margin_percent'] / 100)
            
            if dm.save_data("SERVICE_PRODUCT", edited_df):
                success_toast("Changes Saved Successfully!")
                time.sleep(1)
                st.rerun()
            else:
                error_toast("Failed to save changes.")
                
        # Delete Section
        st.markdown("### 🗑️ Delete Service")
        with st.expander("Delete Options"):
            del_id = st.selectbox("Select Service to Delete", df_svc['service_id'].tolist())
            if st.button("Delete Selected Service", type="primary"):
                delete_service_handler(del_id)

    else:
        st.info("No services found. Add one above!")

# ==========================
# TAB 2: LOCATIONS
# ==========================
with tab2:
    st.subheader("📍 Route Locations")
    
    col_l1, col_l2 = st.columns([2, 1])
    with col_l1:
        loc_search = st.text_input("🔍 Search Locations")
    
    # Add Location Form
    with st.expander("➕ Add New Location"):
        with st.form("new_loc_form"):
            l_city = st.text_input("City")
            l_attr = st.text_input("Attraction Name")
            c_lat, c_lon = st.columns(2)
            l_lat = c_lat.number_input("Latitude", format="%.6f")
            l_lon = c_lon.number_input("Longitude", format="%.6f")
            
            if st.form_submit_button("Save Location"):
                if l_city and l_attr:
                    dm.add_record("LOCATION", {
                        "city": l_city,
                        "attraction_name": l_attr,
                        "latitude": l_lat,
                        "longitude": l_lon
                    })
                    success_toast("Location Added")
                    st.rerun()
                else:
                    error_toast("City and Attraction Name required")

    # Load Data
    if loc_search:
        df_loc = dm.search_records("LOCATION", loc_search)
    else:
        df_loc = dm.load_data("LOCATION")
        
    if not df_loc.empty:
        # User Friendly Table
        st.dataframe(
            df_loc, 
            column_config={
                "latitude": st.column_config.NumberColumn("Lat", format="%.4f"),
                "longitude": st.column_config.NumberColumn("Lon", format="%.4f")
            },
            hide_index=True,
            width='stretch'
        )
        
        # Simple Delete for Locations
        with st.popover("🗑️ Delete Location"):
            loc_to_del = st.selectbox("Choose Location", df_loc['location_id'].tolist())
            if st.button("Confirm Delete"):
                delete_location_handler(loc_to_del)
    else:
        st.info("No locations found.")

# ==========================
# TAB 3: PACKAGES
# ==========================
with tab3:
    st.subheader("📦 Package Bundles")
    
    c_pkg1, c_pkg2 = st.columns([1, 1])
    
    # Left: Create Package
    with c_pkg1:
        with st.container(border=True):
            st.markdown("### Create New Package")
            pkg_name = st.text_input("Package Name")
            pkg_desc = st.text_area("Description")
            
            # Select Services
            all_svcs = dm.load_data("SERVICE_PRODUCT")
            if not all_svcs.empty:
                s_opts = all_svcs['service_name'].tolist()
                sel_svcs = st.multiselect("Select Included Services", s_opts)
                
                # Qty for each
                pkg_items = []
                total_est_price = 0.0
                
                if sel_svcs:
                    st.caption("Configure Quantities:")
                    for s_name in sel_svcs:
                        s_row = all_svcs[all_svcs['service_name'] == s_name].iloc[0]
                        base_p = float(s_row['standard_selling_price'])
                        
                        col_q1, col_q2 = st.columns([2, 1])
                        col_q1.text(f"{s_name} (${base_p:.2f})")
                        qty = col_q2.number_input(f"Qty", min_value=1, value=1, key=f"pkg_q_{s_name}", label_visibility="collapsed")
                        
                        pkg_items.append({
                            "service_id": s_row['service_id'],
                            "quantity": qty
                        })
                        total_est_price += (base_p * qty)
                    
                    st.divider()
                    st.info(f"Calculated Total Value: ${total_est_price:,.2f}")
                    
                    final_price = st.number_input("Package Price", value=total_est_price)
                    
                    if st.button("💾 Save Package", type="primary"):
                        if pkg_name and pkg_items:
                            # Save Def
                            p_rec = {
                                "package_name": pkg_name,
                                "description": pkg_desc,
                                "total_price": final_price
                            }
                            # Need ID back to save items
                            # Manually generating ID first
                            pid = dm.generate_id("PACKAGE_DEF")
                            p_rec['package_id'] = pid
                            
                            if dm.add_record("PACKAGE_DEF", p_rec):
                                # Save Items
                                for pi in pkg_items:
                                    pi['package_id'] = pid
                                    dm.add_record("PACKAGE_ITEMS", pi)
                                    
                                success_toast(f"Package {pid} Created!")
                                time.sleep(1)
                                st.rerun()
                        else:
                            error_toast("Name and Services required")
            else:
                st.warning("No services available to bundle.")

    # Right: List Packages
    with c_pkg2:
        st.markdown("### Existing Packages")
        packages = dm.load_data("PACKAGE_DEF")
        if not packages.empty:
            for _, p in packages.iterrows():
                with st.expander(f"{p['package_name']} (${p['total_price']})"):
                    st.caption(p['description'])
                    if st.button("🗑️ Delete Package", key=f"del_pkg_{p['package_id']}"):
                         # Delete Def (Items remain orphaned in Excel but logic covers it - ideally delete both, 
                         # but DataManager generic delete is single table. For MVP fine.)
                         dm.delete_record("PACKAGE_DEF", p['package_id'])
                         st.rerun()
        else:
            st.info("No packages defined.")
