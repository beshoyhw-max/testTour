import streamlit as st
import pandas as pd
from datetime import datetime, timedelta
import sys
import os

# Ensure modules path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from modules.data_manager import DataManager
from modules.itinerary_exporter import ItineraryExporter
from modules.itinerary_generator import ItineraryGenerator
from modules.ui_components import render_header

# Page Setup
st.set_page_config(page_title="Itinerary Detail", page_icon="📋", layout="wide")

# Helpers
def success_toast(msg):
    st.toast(msg, icon="✅")

def error_toast(msg):
    st.toast(msg, icon="❌")

# Init
dm = DataManager()
ie = ItineraryExporter()
ig = ItineraryGenerator(dm)

# --- Logic to retrieve Order ID ---
if 'itinerary_order_id' not in st.session_state:
    # If accessed directly without state, allow selection
    render_header("Itinerary Builder", "📋")
    st.warning("No active order selected from Orders page.")
    
    all_orders = dm.load_data("ORDER_HEADER")
    if not all_orders.empty:
        sel_oid = st.selectbox("Select Order to Manage", all_orders['order_id'].tolist())
        if st.button("Load Itinerary"):
            st.session_state['itinerary_order_id'] = sel_oid
            st.rerun()
    else:
        st.error("No orders found in system.")
    st.stop()

order_id = st.session_state['itinerary_order_id']
render_header(f"Trip Itinerary: {order_id}", "📋")

# Back Button
if st.button("⬅️ Back to Orders"):
    st.switch_page("pages/1_Orders.py")

st.divider()

# Load Data
all_orders = dm.load_data("ORDER_HEADER")
if order_id not in all_orders['order_id'].values:
    st.error(f"Order {order_id} not found.")
    if st.button("Clear Selection"):
        del st.session_state['itinerary_order_id']
        st.rerun()
    st.stop()
    
order_row = all_orders[all_orders['order_id'] == order_id].iloc[0]
cust_name = "Unknown"
cust_data = dm.load_data("CUSTOMER")
if not cust_data.empty:
    c_match = cust_data[cust_data['customer_id'] == order_row['customer_id']]
    if not c_match.empty:
        cust_name = c_match.iloc[0]['name']

st.info(f"**Customer:** {cust_name} | **Dates:** {order_row['trip_start_date']} to {order_row['trip_end_date']}")

# --- ITINERARY LOGIC ---

# 1. LOAD DATA
all_itn = dm.load_data("ITINERARY")
order_itn = all_itn[all_itn['order_id'] == order_id].copy()

# Sort: Date then Start Time
if not order_itn.empty:
    order_itn['date'] = pd.to_datetime(order_itn['date']).dt.normalize()
    order_itn = order_itn.sort_values(by=['date', 'start_time'])

# 2. GENERATION ACTIONS
c_gen1, c_gen2 = st.columns([3, 1])
with c_gen1:
    st.caption("Manage your trip schedule below.")
with c_gen2:
    if st.button("🔄 Generate from Services", help="Auto-create entries from Order Items", use_container_width=True):
        generated = ig.generate_from_order(order_id)
        if generated:
            count = 0
            for entry in generated:
                # Check duplication? 
                # Simple check: if linked_item_id already exists in current itinerary, skip
                # Or just add all and let user delete? 
                # Let's simple check linked_item_id
                is_dupe = False
                if not order_itn.empty and 'linked_item_id' in order_itn.columns:
                     if entry['linked_item_id'] in order_itn['linked_item_id'].values:
                         is_dupe = True
                
                if not is_dupe:
                    dm.add_record("ITINERARY", entry)
                    count += 1
            
            if count > 0:
                success_toast(f"Generated {count} entries")
                st.rerun()
            else:
                st.info("No new services to add.")
        else:
            st.warning("No services found in order.")

# Layout
col_list, col_form = st.columns([1.5, 1])

# 3. ADD / EDIT FORM (Right Column)
with col_form:
    st.markdown("### ➕ Add Entry")
    with st.container(border=True):
        # Load Order Items for Picker
        o_items = dm.load_data("ORDER_ITEM")
        p_items = o_items[o_items['order_id'] == order_id]
        
        # Prepare Options
        # Format: "Day X: Service Name"
        svc_options = {"None": "✨ Custom Entry (No Link)"}
        for _, item in p_items.iterrows():
            lbl = f"Day {item.get('day_number', '?')}: {item.get('service_name', 'Unknown')}"
            svc_options[item['item_id']] = lbl
            
        with st.form(key="add_itn_form"):
            # Link Picker
            sel_link_id = st.selectbox("🔗 Link to Service", options=list(svc_options.keys()), format_func=lambda x: svc_options[x])
            
            # Auto-fill values based on selection?
            # Streamlit forms don't update dynamically easily without rerun/session state.
            # We'll just init defaults. If user wants auto-fill, they use Generate button mostly.
            # But for manual picking, we can try to be smart if we move this out of form?
            # For now, let's keep it simple: Select box links it, user types details.
            # IMPROVEMENT: If we want auto-fill, we need to use st.session_state and rerun on change of selectbox outside form.
            
            i_date = st.date_input("Date", value=pd.to_datetime(order_row['trip_start_date']))
            
            c_t1, c_t2 = st.columns(2)
            i_start = c_t1.time_input("Start Time", value=datetime.strptime("09:00", "%H:%M").time())
            i_end = c_t2.time_input("End Time", value=datetime.strptime("10:00", "%H:%M").time())
            
            i_city = st.text_input("City / Route (e.g. 开罗 → 阿斯旺)")
            i_act = st.text_input("Activity (具体安排)")
            
            i_note = st.text_area("Notes / Transport (备注/交通)", height=80)
            i_acc = st.text_input("Accommodation (住宿)")
            
            submitted = st.form_submit_button("Add Itinerary Entry", use_container_width=True)
            if submitted:
                link_val = None if sel_link_id == "None" else sel_link_id
                
                new_entry = {
                    "order_id": order_id,
                    "date": i_date,
                    "start_time": i_start.strftime("%H:%M"),
                    "end_time": i_end.strftime("%H:%M"),
                    "city_route": i_city,
                    "activity": i_act,
                    "notes": i_note,
                    "accommodation": i_acc,
                    "linked_item_id": link_val,
                    "is_locked": False
                }
                dm.add_record("ITINERARY", new_entry)
                success_toast("Entry Added")
                st.rerun()

# 4. LIST VIEW (Left Column)
with col_list:
    st.markdown("### 📅 Schedule")
    
    if not order_itn.empty:
        # Group by Date
        dates = sorted(order_itn['date'].unique())
        
        for d in dates:
            d_str = pd.to_datetime(d).strftime('%Y-%m-%d (%A)')
            d_entries = order_itn[order_itn['date'] == d]
            
            with st.expander(f"**{d_str}** ({len(d_entries)} items)", expanded=True):
                for _, row in d_entries.iterrows():
                    # Check connection
                    is_linked = False
                    if 'linked_item_id' in row and pd.notna(row['linked_item_id']):
                        is_linked = True
                        
                    # Edit State Key
                    edit_key = f"edit_mode_{row['entry_id']}"
                    
                    with st.container(border=True):
                        # --- VIEW MODE ---
                        if edit_key not in st.session_state:
                            c1, c2 = st.columns([5, 1])
                            with c1:
                                time_range = f"{row['start_time']} - {row['end_time']}" if row['end_time'] else f"{row['start_time']}"
                                link_badge = "🔗 " if is_linked else ""
                                st.markdown(f"**{time_range}** | {link_badge}{row['city_route']}")
                                st.markdown(f"*{row['activity']}*")
                                if row['notes']: st.caption(f"📝 {row['notes']}")
                                if row['accommodation']: st.caption(f"🏨 {row['accommodation']}")
                                
                            with c2:
                                # Tools Column
                                if st.button("✏️", key=f"btn_edit_{row['entry_id']}", help="Edit Entry"):
                                    st.session_state[edit_key] = True
                                    st.rerun()
                                    
                                if st.button("🗑️", key=f"del_{row['entry_id']}", help="Delete Entry"):
                                    dm.delete_record("ITINERARY", row['entry_id'])
                                    st.rerun()
                                
                                if is_linked:
                                    if st.button("🔓", key=f"unlink_{row['entry_id']}", help="Unlink from Service"):
                                        dm.update_record("ITINERARY", row['entry_id'], {"linked_item_id": None})
                                        st.rerun()
                        
                        # --- EDIT MODE ---
                        else:
                            st.caption(f"✏️ Editing Entry {row['entry_id']}")
                            with st.form(key=f"form_edit_{row['entry_id']}"):
                                ce1, ce2 = st.columns(2)
                                e_start = ce1.time_input("Start", value=datetime.strptime(row['start_time'], "%H:%M").time(), key=f"es_{row['entry_id']}")
                                e_end = ce2.time_input("End", value=datetime.strptime(row['end_time'], "%H:%M").time() if row['end_time'] else datetime.strptime("10:00", "%H:%M").time(), key=f"ee_{row['entry_id']}")
                                
                                e_city = st.text_input("City/Route", value=row['city_route'], key=f"ec_{row['entry_id']}")
                                e_act = st.text_input("Activity", value=row['activity'], key=f"ea_{row['entry_id']}")
                                e_note = st.text_area("Notes", value=row['notes'], key=f"en_{row['entry_id']}")
                                e_acc = st.text_input("Accommodation", value=row['accommodation'], key=f"eh_{row['entry_id']}")
                                
                                c_save, c_can = st.columns(2)
                                if c_save.form_submit_button("💾 Save", use_container_width=True):
                                    updates = {
                                        "start_time": e_start.strftime("%H:%M"),
                                        "end_time": e_end.strftime("%H:%M"),
                                        "city_route": e_city,
                                        "activity": e_act,
                                        "notes": e_note,
                                        "accommodation": e_acc
                                    }
                                    dm.update_record("ITINERARY", row['entry_id'], updates)
                                    del st.session_state[edit_key]
                                    st.rerun()
                                    
                                if c_can.form_submit_button("❌ Cancel", use_container_width=True):
                                    del st.session_state[edit_key]
                                    st.rerun()
    else:
        st.info("No itinerary entries yet. Use 'Generate' or add manually.")

st.divider()

# 5. EXPORT ACTIONS
st.subheader("📤 Export / Download")
ex1, ex2 = st.columns(2)

with ex1:
    if st.button("📥 Export Excel (Vendor)", use_container_width=True):
        xl_data = ie.generate_excel(order_itn)
        if xl_data:
            st.download_button(
                label="Download Excel File",
                data=xl_data,
                file_name=f"Itinerary_{order_id}.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                key="dl_xl_pg"
            )

with ex2:
    if st.button("📄 Export PDF (Client)", use_container_width=True):
        pdf_data = ie.generate_pdf(order_id, order_itn)
        if pdf_data:
            st.download_button(
                label="Download PDF File",
                data=pdf_data,
                file_name=f"Itinerary_{order_id}.pdf",
                mime="application/pdf",
                key="dl_pdf_pg"
            )
