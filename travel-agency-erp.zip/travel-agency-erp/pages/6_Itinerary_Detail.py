import streamlit as st
import pandas as pd
from datetime import datetime
import sys
import os

# Ensure modules path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from modules.data_manager import DataManager
from modules.itinerary_exporter import ItineraryExporter
from modules.ui_components import render_header

# Page Setup
st.set_page_config(page_title="Itinerary Detail", page_icon="📋", layout="wide")

# Helpers
def success_toast(msg):
    st.toast(msg, icon="✅")

def error_toast(msg):
    st.toast(msg, icon="❌")

# Init
dm = DataManager()
ie = ItineraryExporter()

# --- Logic to retrieve Order ID ---
if 'itinerary_order_id' not in st.session_state:
    # If accessed directly without state, allow selection
    render_header("Itinerary Builder", "📋")
    st.warning("No active order selected from Orders page.")
    
    all_orders = dm.load_data("ORDER_HEADER")
    if not all_orders.empty:
        sel_oid = st.selectbox("Select Order to Manage", all_orders['order_id'].tolist())
        if st.button("Load Itinerary"):
            st.session_state['itinerary_order_id'] = sel_oid
            st.rerun()
    else:
        st.error("No orders found in system.")
    st.stop()

order_id = st.session_state['itinerary_order_id']
render_header(f"Trip Itinerary: {order_id}", "📋")

# Back Button
if st.button("⬅️ Back to Orders"):
    st.switch_page("pages/1_Orders.py")

st.divider()

# Load Data
all_orders = dm.load_data("ORDER_HEADER")
if order_id not in all_orders['order_id'].values:
    st.error(f"Order {order_id} not found.")
    if st.button("Clear Selection"):
        del st.session_state['itinerary_order_id']
        st.rerun()
    st.stop()
    
order_row = all_orders[all_orders['order_id'] == order_id].iloc[0]
cust_name = "Unknown"
cust_data = dm.load_data("CUSTOMER")
if not cust_data.empty:
    c_match = cust_data[cust_data['customer_id'] == order_row['customer_id']]
    if not c_match.empty:
        cust_name = c_match.iloc[0]['name']

st.info(f"**Customer:** {cust_name} | **Dates:** {order_row['trip_start_date']} to {order_row['trip_end_date']}")

# --- ITINERARY LOGIC ---

# Load Itinerary Data
all_itn = dm.load_data("ITINERARY")
order_itn = all_itn[all_itn['order_id'] == order_id].copy()

# Sort: Date then Start Time
if not order_itn.empty:
    order_itn['date'] = pd.to_datetime(order_itn['date'])
    order_itn = order_itn.sort_values(by=['date', 'start_time'])

# Layout
col_list, col_form = st.columns([1.5, 1])

# 1. ADD / EDIT FORM (Right Column)
with col_form:
    st.markdown("### ➕ Add Entry")
    with st.container(border=True):
        with st.form(key="add_itn_form"):
            i_date = st.date_input("Date", value=pd.to_datetime(order_row['trip_start_date']))
            
            c_t1, c_t2 = st.columns(2)
            i_start = c_t1.time_input("Start Time", value=datetime.strptime("09:00", "%H:%M").time())
            i_end = c_t2.time_input("End Time", value=datetime.strptime("10:00", "%H:%M").time())
            
            i_city = st.text_input("City / Route (e.g. 开罗 → 阿斯旺)")
            i_act = st.text_input("Activity (具体安排)")
            
            i_note = st.text_area("Notes / Transport (备注/交通)", height=80)
            i_acc = st.text_input("Accommodation (住宿)")
            
            submitted = st.form_submit_button("Add Itinerary Entry", use_container_width=True)
            if submitted:
                new_entry = {
                    "order_id": order_id,
                    "date": i_date,
                    "start_time": i_start.strftime("%H:%M"),
                    "end_time": i_end.strftime("%H:%M"),
                    "city_route": i_city,
                    "activity": i_act,
                    "notes": i_note,
                    "accommodation": i_acc
                }
                dm.add_record("ITINERARY", new_entry)
                success_toast("Entry Added")
                st.rerun()

# 2. LIST VIEW (Left Column)
with col_list:
    st.markdown("### 📅 Schedule")
    
    if not order_itn.empty:
        # Group by Date
        dates = sorted(order_itn['date'].unique())
        
        for d in dates:
            d_str = pd.to_datetime(d).strftime('%Y-%m-%d (%A)')
            d_entries = order_itn[order_itn['date'] == d]
            
            with st.expander(f"**{d_str}** ({len(d_entries)} items)", expanded=True):
                for _, row in d_entries.iterrows():
                    # Card-like display
                    with st.container(border=True):
                        c1, c2 = st.columns([4, 1])
                        with c1:
                            time_range = f"{row['start_time']} - {row['end_time']}" if row['end_time'] else f"{row['start_time']}"
                            st.markdown(f"**{time_range}** | {row['city_route']}")
                            st.markdown(f"*{row['activity']}*")
                            if row['notes']: st.caption(f"📝 {row['notes']}")
                            if row['accommodation']: st.caption(f"🏨 {row['accommodation']}")
                        with c2:
                            if st.button("🗑️", key=f"del_{row['entry_id']}", help="Delete Entry"):
                                dm.delete_record("ITINERARY", row['entry_id'])
                                st.rerun()
    else:
        st.info("No itinerary entries yet. Add one on the right.")

st.divider()

# 3. EXPORT ACTIONS
st.subheader("📤 Export / Download")
ex1, ex2 = st.columns(2)

with ex1:
    if st.button("📥 Export Excel (Vendor)", use_container_width=True):
        xl_data = ie.generate_excel(order_itn)
        if xl_data:
            st.download_button(
                label="Download Excel File",
                data=xl_data,
                file_name=f"Itinerary_{order_id}.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                key="dl_xl_pg"
            )

with ex2:
    if st.button("📄 Export PDF (Client)", use_container_width=True):
        pdf_data = ie.generate_pdf(order_id, order_itn)
        if pdf_data:
            st.download_button(
                label="Download PDF File",
                data=pdf_data,
                file_name=f"Itinerary_{order_id}.pdf",
                mime="application/pdf",
                key="dl_pdf_pg"
            )
