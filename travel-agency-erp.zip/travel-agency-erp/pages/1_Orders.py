import streamlit as st
import pandas as pd
import sys
import os
import time
from datetime import datetime
import math

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from modules.data_manager import DataManager
from modules.logistics import LogisticsManager
from modules.invoice_generator import InvoiceGenerator
from modules.itinerary_exporter import ItineraryExporter

# Page Config
st.set_page_config(page_title="Order Management", page_icon="📝", layout="wide")

dm = DataManager()
lm = LogisticsManager()
ig = InvoiceGenerator()
ie = ItineraryExporter()

# --- HELPERS ---
def success_toast(msg):
    st.toast(msg, icon="✅")
    time.sleep(0.5)

def format_currency(val):
    return f"${val:,.2f}"

from modules.ui_components import render_header

# --- CALLBACKS ---
def convert_order_callback(oid):
    updates = {
        "status": "Pending",
        "trip_start_date": datetime.now()
    }
    if dm.update_record("ORDER_HEADER", oid, updates):
        st.session_state[f"stat_{oid}"] = "Pending"
        success_toast(f"Quote converted to Order {oid}")

def add_payment_callback(oid, amount, current_paid, total_rev):
    new_paid = float(current_paid) + amount
    if new_paid > float(total_rev):
        st.toast(f"❌ Error: Total paid (${new_paid:,.2f}) cannot exceed Total Revenue (${float(total_rev):,.2f})", icon="⚠️")
        return

    updates = {
        "deposit_paid": new_paid,
        "balance_due": float(total_rev) - new_paid
    }
    if dm.update_record("ORDER_HEADER", oid, updates):
        st.session_state[f"dep_{oid}"] = new_paid
        success_toast("Payment Recorded")


# --- PRINT MODE CHECK ---
if "print_order" in st.session_state:
    p_data = st.session_state.print_order
    row = p_data['header']
    items = p_data['items']
    
    st.markdown(f"""
    <div style="padding: 20px; border: 1px solid #ccc;">
        <h1>Order #{row['order_id']}</h1>
        <h3>Customer ID: {row['customer_id']}</h3>
        <p><strong>Status:</strong> {row['status']}</p>
        <p><strong>Trip Dates:</strong> {row['trip_start_date']} to {row['trip_end_date']}</p>
        <hr>
        <table style="width:100%; border-collapse: collapse;">
            <tr style="background:#eee;">
                 <th style="padding:8px; border:1px solid #ddd; text-align:left;">Service</th>
                 <th style="padding:8px; border:1px solid #ddd;">Qty</th>
                 <th style="padding:8px; border:1px solid #ddd;">Price</th>
                 <th style="padding:8px; border:1px solid #ddd;">Total</th>
            </tr>
    """, unsafe_allow_html=True)
    
    for _, item in items.iterrows():
         # Load service name if possible or use ID
         st.markdown(f"""
            <tr>
                 <td style="padding:8px; border:1px solid #ddd;">{item['service_id']}</td>
                 <td style="padding:8px; border:1px solid #ddd; text-align:center;">{item['quantity']}</td>
                 <td style="padding:8px; border:1px solid #ddd; text-align:right;">${item['selling_price']:.2f}</td>
                 <td style="padding:8px; border:1px solid #ddd; text-align:right;">${(item['selling_price']*item['quantity']):.2f}</td>
            </tr>
         """, unsafe_allow_html=True)
         
    st.markdown(f"""
        </table>
        <h3 style="text-align:right; margin-top:20px;">Total: ${row['total_revenue']:,.2f}</h3>
        <h4 style="text-align:right;">Paid: ${row['deposit_paid']:,.2f}</h4>
        <h2 style="text-align:right; color: #d9534f;">Due: ${row['balance_due']:,.2f}</h2>
        <p style="margin-top: 50px;"><em>Notes: {row.get('notes', '')}</em></p>
    </div>
    <br>
    """, unsafe_allow_html=True)
    
    if st.button("⬅️ Back to Dashboard"):
        del st.session_state.print_order
        st.rerun()
    
    st.stop() # Stop rendering the rest of the page

# --- MAIN PAGE ---
render_header("Order Management", "📝")

tab1, tab2 = st.tabs(["➕ Create New Order", "📂 Manage Orders"])

# ==========================
# TAB 1: NEW ORDER WIZARD
# ==========================
with tab1:
    # Session State for Wizard
    if "order_step" not in st.session_state:
        st.session_state.order_step = 1
    if "order_items" not in st.session_state:
        st.session_state.order_items = []
        
    # Progress Bar
    steps = ["Customer & Trip", "Add Services", "Review & Submit"]
    curr_step = st.session_state.order_step
    
    # Edit Mode Banner
    if "editing_quote_id" in st.session_state:
        st.warning(f"✏️ Editing Quote: {st.session_state.editing_quote_id}")
        if st.button("Cancel Edit"):
            del st.session_state.editing_quote_id
            st.session_state.order_step = 1
            st.session_state.order_items = []
            st.rerun()

    st.progress(curr_step / 3)
    st.caption(f"Step {curr_step}: {steps[curr_step-1]}")

    # --- STEP 1: CUSTOMER ---
    if curr_step == 1:
        st.subheader("Step 1: Customer & Trip Details")
        
        customers = dm.load_data("CUSTOMER")
        if customers.empty:
            st.warning("No customers found. Please go to Settings to add one.")
            st.stop()
            
        c1, c2 = st.columns(2)
        with c1:
            cust_names = customers['name'].tolist()
            sel_cust = st.selectbox("Select Customer", cust_names, key="ord_cust_sel")
            # Get Customer ID
            cust_row = customers[customers['name'] == sel_cust].iloc[0]
            st.session_state.ord_cust_id = cust_row['customer_id']
            st.info(f"📧 {cust_row.get('email', 'N/A')} | 📞 {cust_row.get('phone', 'N/A')}")
            
        with c2:
            c2a, c2b = st.columns(2)
            start_d = c2a.date_input("Trip Start", key="ord_start")
            end_d = c2b.date_input("Trip End", key="ord_end")
            pax = st.number_input("Pax Count", min_value=1, value=2, key="ord_pax")
            
        if st.button("Next: Add Services ➡️"):
            # Persist values because widget keys are cleared when removed from DOM
            st.session_state.saved_ord_start = st.session_state.ord_start
            st.session_state.saved_ord_end = st.session_state.ord_end
            st.session_state.saved_ord_pax = st.session_state.ord_pax
            st.session_state.order_step = 2
            st.rerun()

    # --- STEP 2: SERVICES ---
    elif curr_step == 2:
        st.subheader("Step 2: Add Services & Products")
        
        c_main, c_cart = st.columns([2, 1])
        
        with c_main:
            tab_svc, tab_pkg = st.tabs(["🛒 Individual Services", "📦 Packages"])
            
            # --- INDIVIDUAL SERVICES ---
            with tab_svc:
                # Removed st.form to allow real-time updates of Cost/Price when Service changes
                services = dm.load_data("SERVICE_PRODUCT")
                vendors = dm.load_data("VENDOR")
                locations = dm.load_data("LOCATION")
                
                if services.empty:
                    st.error("No services available.")
                else:
                    # --- CITY FILTER ---
                    # Get all unique cities from Services and Locations
                    svc_cities = services['city'].unique().tolist() if 'city' in services.columns else []
                    loc_cities = locations['city'].unique().tolist() if 'city' in locations.columns and not locations.empty else []
                    all_cities = sorted(list(set([c for c in svc_cities + loc_cities if pd.notna(c) and str(c).strip() != ""])))
                    
                    if not all_cities:
                        all_cities = ["Default"]
                        
                    sel_city_filter = st.selectbox("🌍 Filter by City", all_cities)
                    
                    # FILTER SERVICES BY CITY
                    if 'city' in services.columns:
                        city_services = services[services['city'] == sel_city_filter].copy()
                    else:
                        city_services = services.copy()

                    # Service Filter (Category) based on City Services
                    svc_types = ["All"] + sorted(city_services['service_type'].astype(str).unique().tolist())
                    type_filter = st.radio("Filter Category", svc_types, horizontal=True)
                    
                    if type_filter != "All":
                        filtered_svc = city_services[city_services['service_type'] == type_filter].copy()
                    else:
                        filtered_svc = city_services

                    
                    # Service Selection - sort by Favorite then Name
                    if 'is_favorite' not in filtered_svc.columns:
                        filtered_svc['is_favorite'] = False
                    
                    filtered_svc['is_favorite'] = filtered_svc['is_favorite'].fillna(False).astype(bool)
                    filtered_svc = filtered_svc.sort_values(by=['is_favorite', 'service_name'], ascending=[False, True])

                    if filtered_svc.empty:
                        st.warning("No services found in this category.")
                        s_names = []
                    else:
                        s_names = []
                        for _, s_row in filtered_svc.iterrows():
                            prefix = "⭐ " if s_row['is_favorite'] else ""
                            s_names.append(f"{prefix}{s_row['service_name']}")
                    
                    sel_svc_raw = st.selectbox("Choose Service", s_names)
                    
                    if sel_svc_raw:
                        sel_svc_name = sel_svc_raw.replace("⭐ ", "")
                    else:
                        sel_svc_name = None
                    
                    if s_names and sel_svc_name:
                        # Get Service Details to pre-fill
                        svc_row = services[services['service_name'] == sel_svc_name].iloc[0]
                        svc_id = svc_row['service_id']
                        svc_type = svc_row['service_type']
                        base_cost = float(svc_row['default_base_cost'])
                        def_margin = float(svc_row['default_profit_margin_percent'])
                        
                        st.caption(f"Type: {svc_type} | Base Cost: {format_currency(base_cost)}")

                        # Filter Vendors
                        if not vendors.empty:
                            filtered_vendors = vendors[
                                vendors['vendor_type'].astype(str).str.contains(svc_type, case=False, na=False) |
                                (vendors['vendor_type'] == "Other")
                            ]
                            if filtered_vendors.empty:
                                v_opts = vendors['vendor_name'].tolist()
                            else:
                                v_opts = filtered_vendors['vendor_name'].tolist()
                        else:
                            v_opts = ["No Vendors Found"]

                        sel_ven_name = st.selectbox("Assign Vendor", v_opts)
                        
                        # Financials
                        fc1, fc2 = st.columns(2)
                        qty = fc1.number_input("Qty", min_value=1, value=1, key=f"qty_{sel_svc_name}")
                        cost = fc2.number_input("Unit Cost ($)", value=base_cost, format="%.2f", key=f"cost_{sel_svc_name}")
                        
                        fc3, fc4 = st.columns(2)
                        margin = fc3.number_input("Margin (%)", value=def_margin, format="%.2f", key=f"margin_{sel_svc_name}")
                        
                        # --- CAR LOCATION & DISTANCE LOGIC ---
                        sel_locations = []
                        dist_msg = ""
                        
                        if "Car" in svc_type:
                            st.markdown("### 📍 Itinerary Locations")
                            # Filter locations by City
                            if not locations.empty:
                                city_locs = locations[locations['city'] == sel_city_filter]
                                if not city_locs.empty:
                                    loc_names = city_locs['attraction_name'].tolist()
                                    sel_locations = st.multiselect("Select Itinerary Points (in order)", loc_names, key=f"locs_{sel_svc_name}")
                                    
                                    # Calculate Distance
                                    if len(sel_locations) > 1:
                                        total_dist = 0.0
                                        points = []
                                        # Get coords
                                        for loc_name in sel_locations:
                                            l_row = city_locs[city_locs['attraction_name'] == loc_name].iloc[0]
                                            try:
                                                lat = float(l_row['latitude'])
                                                lon = float(l_row['longitude'])
                                                points.append((lat, lon))
                                            except:
                                                pass
                                        
                                        if len(points) >= 2:
                                            for i in range(len(points) - 1):
                                                p1 = points[i]
                                                p2 = points[i+1]
                                                # Haversine Formula
                                                R = 6371  # Earth radius in km
                                                dlat = math.radians(p2[0] - p1[0])
                                                dlon = math.radians(p2[1] - p1[1])
                                                a = math.sin(dlat/2) * math.sin(dlat/2) + \
                                                    math.cos(math.radians(p1[0])) * math.cos(math.radians(p2[0])) * \
                                                    math.sin(dlon/2) * math.sin(dlon/2)
                                                c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
                                                d = R * c
                                                total_dist += d
                                            
                                            dist_msg = f"📉 Est. Distance: **{total_dist:.2f} km**"
                                            st.markdown(dist_msg)
                                else:
                                    st.warning(f"No locations defined for {sel_city_filter}.")
                            else:
                                st.warning("No locations database found.")

                        
                        # Itinerary Details
                        st.markdown("**Itinerary Details**")
                        it1, it2 = st.columns(2)
                        day_num = it1.number_input("Day #", min_value=1, value=1, key=f"day_{sel_svc_name}")
                        
                        start_time_str = ""
                        if it2.checkbox("Set Time", value=False, key=f"has_time_{sel_svc_name}"):
                            start_t = it2.time_input("Start Time", value=datetime.strptime("09:00", "%H:%M").time(), key=f"time_{sel_svc_name}")
                            start_time_str = start_t.strftime("%H:%M")
                        
                        sell_price = cost * (1 + margin/100)
                        fc4.metric("Unit Price", format_currency(sell_price))
                        
                        if st.button("Add to Order", type="primary"):
                            # Resolve Vendor
                            ven_id = "N/A"
                            if not vendors.empty and sel_ven_name != "No Vendors Found":
                                v_row = vendors[vendors['vendor_name'] == sel_ven_name]
                                if not v_row.empty:
                                    ven_id = v_row.iloc[0]['vendor_id']
                            
                            item = {
                                "service_id": svc_id,
                                "service_name": sel_svc_name,
                                "vendor_id": ven_id,
                                "vendor_name": sel_ven_name,
                                "quantity": qty,
                                "actual_cost": cost,
                                "profit_margin_percent": margin,
                                "selling_price": sell_price,
                                "total": sell_price * qty,
                                "profit": (sell_price - cost) * qty,
                                "day_number": day_num,
                                "start_time": start_time_str,
                                "location": ", ".join(sel_locations) if sel_locations else ""
                            }
                            st.session_state.order_items.append(item)
                            success_toast(f"Item Added {dist_msg}")
                            st.rerun()

            # --- PACKAGES ---
            with tab_pkg:
                st.markdown("### 📦 Available Packages")
                packages = dm.load_data("PACKAGE_DEF")
                if not packages.empty:
                    for _, pkg in packages.iterrows():
                        with st.container(border=True):
                            c_p1, c_p2 = st.columns([3, 1])
                            c_p1.subheader(pkg['package_name'])
                            c_p1.caption(pkg['description'])
                            c_p1.text(f"Price: ${pkg['total_price']:,.2f}")
                            
                            if c_p2.button("Add Bundle", key=f"add_pkg_{pkg['package_id']}"):
                                # 1. Fetch Items
                                pkg_items_db = dm.load_data("PACKAGE_ITEMS")
                                p_items = pkg_items_db[pkg_items_db['package_id'] == pkg['package_id']]
                                
                                # 2. Fetch Service Details for each
                                services = dm.load_data("SERVICE_PRODUCT")
                                
                                for _, pi in p_items.iterrows():
                                    s_row = services[services['service_id'] == pi['service_id']].iloc[0]
                                    
                                    # Default calculations using standard logic
                                    cost = float(s_row['default_base_cost'])
                                    margin = float(s_row['default_profit_margin_percent'])
                                    sell = cost * (1 + margin/100)
                                    q = int(pi['quantity'])
                                    
                                    item = {
                                        "service_id": pi['service_id'],
                                        "service_name": s_row['service_name'],
                                        "vendor_id": "N/A", # Needs assignment later
                                        "vendor_name": "Unassigned",
                                        "quantity": q,
                                        "actual_cost": cost,
                                        "profit_margin_percent": margin,
                                        "selling_price": sell,
                                        "total": sell * q,
                                        "profit": (sell - cost) * q,
                                        "day_number": 1, # Default to Day 1
                                        "start_time": "09:00"
                                    }
                                    st.session_state.order_items.append(item)
                                    
                                success_toast(f"Added {len(p_items)} from {pkg['package_name']}")
                                st.rerun()
                else:
                    st.info("No packages defined.")

        # --- CART COLUMN ---
        with c_cart:
            st.markdown("### 🛒 Cart")
            if st.session_state.order_items:
                # Sort by Day/Time
                st.session_state.order_items.sort(key=lambda x: (x.get('day_number', 1), x.get('start_time', '00:00')))
                
                for idx, item in enumerate(st.session_state.order_items):
                    with st.container(border=True):
                        c1, c2 = st.columns([4, 1])
                        c1.markdown(f"**Day {item.get('day_number', 1)} @ {item.get('start_time', '09:00')}**")
                        c1.text(f"{item['service_name']} (x{item['quantity']})")
                        if item.get('location'):
                            c1.caption(f"📍 {item['location']}")
                        c1.caption(f"{format_currency(item['selling_price'])} ea")
                        
                        if c2.button("❌", key=f"del_item_{idx}"):
                            st.session_state.order_items.pop(idx)
                            st.rerun()
            else:
                st.info("Cart is empty.")

        c_nav1, c_nav2 = st.columns(2)
        if c_nav1.button("⬅️ Back"):
            st.session_state.order_step = 1
            st.rerun()
        if c_nav2.button("Next: Review ➡️"):
            if not st.session_state.order_items:
                st.error("Please add at least one item.")
            else:
                st.session_state.order_step = 3
                st.rerun()

    # --- STEP 3: REVIEW ---
    elif curr_step == 3:
        st.subheader("Step 3: Review & Submit")
        
        # Calculate Totals
        items_df = pd.DataFrame(st.session_state.order_items)
        tot_rev = items_df['total'].sum()
        tot_cost = (items_df['actual_cost'] * items_df['quantity']).sum()
        tot_prof = items_df['profit'].sum()
        
        # Summary Metrics
        m1, m2, m3 = st.columns(3)
        m1.metric("Total Revenue", format_currency(tot_rev))
        m2.metric("Total Profit", format_currency(tot_prof))
        m3.metric("Margin", f"{(tot_prof/tot_rev*100):.1f}%" if tot_rev > 0 else "0%")
        
        st.dataframe(items_df[['day_number', 'start_time', 'service_name', 'quantity', 'selling_price', 'total']], hide_index=True)
        
        deposit = st.number_input("Initial Deposit Received", min_value=0.0, max_value=float(tot_rev), value=0.0)
        
        # Order Notes
        notes = st.text_area("Order Notes", placeholder="Special requests, flight details, dietary restrictions...", key="new_ord_notes")
        
        c_sub1, c_sub2, c_sub3 = st.columns(3)
        if c_sub1.button("⬅️ Back"):
            st.session_state.order_step = 2
            st.rerun()
            
        if c_sub2.button("💾 " + ("Update Quote" if "editing_quote_id" in st.session_state else "Save as Quote")):
             # Create Header as Quote
            if "editing_quote_id" in st.session_state:
                oid = st.session_state.editing_quote_id
                # For updates, we first clear existing items to avoid duplicates
                # Ideally DataManager should handle this, but for now we do simple delete/add pattern or just Add.
                # Since DataManager appends, we must delete old items first.
                items_db = dm.load_data("ORDER_ITEM")
                # Filter out old items
                new_items_db = items_db[items_db['order_id'] != oid]
                dm.save_data("ORDER_ITEM", new_items_db) 
                
                # Update Header (Overwrite)
                updates = {
                    "trip_start_date": st.session_state.saved_ord_start,
                    "trip_end_date": st.session_state.saved_ord_end,
                    "pax_count": st.session_state.saved_ord_pax,
                    "total_cost": tot_cost,
                    "total_revenue": tot_rev,
                    "total_profit": tot_prof,
                    "balance_due": tot_rev, # Reset balance for quote
                    "notes": notes
                }
                dm.update_record("ORDER_HEADER", oid, updates)
                action_msg = f"Quote {oid} Updated Successfully!"
            else:
                oid = dm.generate_id("ORDER_HEADER")
                header = {
                    "order_id": oid,
                    "customer_id": st.session_state.ord_cust_id,
                    "trip_start_date": st.session_state.saved_ord_start,
                    "trip_end_date": st.session_state.saved_ord_end,
                    "pax_count": st.session_state.saved_ord_pax,
                    "status": "Quote",
                    "total_cost": tot_cost,
                    "total_revenue": tot_rev,
                    "total_profit": tot_prof,
                    "deposit_paid": 0.0,
                    "balance_due": tot_rev,
                    "notes": notes
                }
                dm.add_record("ORDER_HEADER", header)
                action_msg = f"Quote {oid} Saved Successfully!"
            
            # Create Items (For both new and update)
            if "editing_quote_id" not in st.session_state:
                # Normal Add logic for new
                 for item in st.session_state.order_items:
                    db_item = {
                        "order_id": oid,
                        "service_id": item['service_id'],
                        "vendor_id": item['vendor_id'],
                        "quantity": item['quantity'],
                        "actual_cost": item['actual_cost'],
                        "profit_margin_percent": item['profit_margin_percent'],
                        "selling_price": item['selling_price'],
                        "day_number": item.get('day_number', 1),
                        "start_time": item.get('start_time', "09:00")
                    }
                    dm.add_record("ORDER_ITEM", db_item)
            else:
                # For update, we already cleared old items above, so just add new ones
                 for item in st.session_state.order_items:
                    db_item = {
                        "order_id": oid,
                        "service_id": item['service_id'],
                        "vendor_id": item['vendor_id'],
                        "quantity": item['quantity'],
                        "actual_cost": item['actual_cost'],
                        "profit_margin_percent": item['profit_margin_percent'],
                        "selling_price": item['selling_price'],
                        "day_number": item.get('day_number', 1),
                        "start_time": item.get('start_time', "09:00")
                    }
                    dm.add_record("ORDER_ITEM", db_item)

            # Cleanup
            st.session_state.order_items = []
            st.session_state.order_step = 1
            if "editing_quote_id" in st.session_state:
                del st.session_state.editing_quote_id
                
            st.success(action_msg)
            time.sleep(2)
            st.rerun()

        if c_sub3.button("✅ CONFIRM ORDER", type="primary"):
            # Create Header
            oid = dm.generate_id("ORDER_HEADER")
            header = {
                "order_id": oid,
                "customer_id": st.session_state.ord_cust_id,
                "trip_start_date": st.session_state.saved_ord_start,
                "trip_end_date": st.session_state.saved_ord_end,
                "pax_count": st.session_state.saved_ord_pax,
                "status": "Confirmed",
                "total_cost": tot_cost,
                "total_revenue": tot_rev,
                "total_profit": tot_prof,
                "deposit_paid": deposit,
                "balance_due": tot_rev - deposit,
                "notes": notes
            }
            dm.add_record("ORDER_HEADER", header)
            
            # Create Items
            for item in st.session_state.order_items:
                db_item = {
                    "order_id": oid,
                    "service_id": item['service_id'],
                    "vendor_id": item['vendor_id'],
                    "quantity": item['quantity'],
                    "actual_cost": item['actual_cost'],
                    "profit_margin_percent": item['profit_margin_percent'],
                    "selling_price": item['selling_price'],
                    "day_number": item.get('day_number', 1),
                    "start_time": item.get('start_time', "09:00")
                }
                dm.add_record("ORDER_ITEM", db_item)
                
            # Update Customer Stats
            customers = dm.load_data("CUSTOMER")
            cust_idx = customers[customers['customer_id'] == st.session_state.ord_cust_id].index
            if not cust_idx.empty:
                curr_cnt = int(customers.loc[cust_idx, 'number_of_orders'].iloc[0] or 0)
                customers.loc[cust_idx, 'number_of_orders'] = curr_cnt + 1
                dm.save_data("CUSTOMER", customers)

            # Reset
            st.session_state.order_items = []
            st.session_state.order_step = 1
            st.success(f"Order {oid} Created Successfully!")
            time.sleep(2)
            st.rerun()

# ==========================
# TAB 2: MANAGE ORDERS
# ==========================
with tab2:
    st.subheader("Manage Orders")
    
    orders = dm.load_data("ORDER_HEADER")
    if orders.empty:
        st.info("No orders found.")
    else:
        # Filters
        st.markdown("### 🔍 Filters")
        c_fil1, c_fil2 = st.columns(2)
        search_txt = c_fil1.text_input("Search Order ID")
        status_fil = c_fil2.multiselect("Status", ["Confirmed", "Pending", "Completed", "Cancelled", "Quote"])
        
        # Apply Filters
        if search_txt:
            orders = orders[orders['order_id'].str.contains(search_txt, case=False)]
        if status_fil:
            orders = orders[orders['status'].isin(status_fil)]
            
        # Display List
        for _, row in orders.iterrows():
            # Label distinction for Quotes
            is_quote = row['status'] == 'Quote'
            label_icon = "📜" if is_quote else "📝"
            
            with st.expander(f"{label_icon} {row['order_id']} | {row['status']} | {format_currency(row['total_revenue'])}"):
                # Quote Conversion Header
                if is_quote:
                    st.info("This is a Quote. Convert to Order to enable financial tracking.")
                    st.button("🚀 Convert to Order", 
                              key=f"conv_{row['order_id']}",
                              on_click=convert_order_callback,
                              args=(row['order_id'],))
                    
                    if st.button("✏️ Edit Quote Items", key=f"edit_{row['order_id']}"):
                        # 1. Load Header Info
                        st.session_state.editing_quote_id = row['order_id']
                        st.session_state.ord_cust_id = row['customer_id']
                        st.session_state.saved_ord_start = pd.to_datetime(row['trip_start_date']).date()
                        st.session_state.saved_ord_end = pd.to_datetime(row['trip_end_date']).date()
                        
                        pax_val = row['pax_count']
                        st.session_state.saved_ord_pax = int(pax_val) if pd.notna(pax_val) else 1
                        
                        # 2. Load Items
                        items_data = dm.load_data("ORDER_ITEM")
                        q_items = items_data[items_data['order_id'] == row['order_id']]
                        
                        loaded_items = []
                        # Need Service Names
                        svcs = dm.load_data("SERVICE_PRODUCT")
                        vens = dm.load_data("VENDOR")
                        
                        for _, qi in q_items.iterrows():
                            # Get Name
                            s_name = "Unknown"
                            s_match = svcs[svcs['service_id'] == qi['service_id']]
                            if not s_match.empty:
                                s_name = s_match.iloc[0]['service_name']
                                
                            v_name = "Unassigned"
                            v_match = vens[vens['vendor_id'] == qi['vendor_id']]
                            if not v_match.empty:
                                v_name = v_match.iloc[0]['vendor_name']
                                
                            loaded_items.append({
                                "service_id": qi['service_id'],
                                "service_name": s_name,
                                "vendor_id": qi['vendor_id'],
                                "vendor_name": v_name,
                                "quantity": int(qi['quantity']),
                                "actual_cost": float(qi['actual_cost']),
                                "profit_margin_percent": float(qi['profit_margin_percent']),
                                "selling_price": float(qi['selling_price']),
                                "total": float(qi['selling_price']) * int(qi['quantity']),
                                "profit": (float(qi['selling_price']) - float(qi['actual_cost'])) * int(qi['quantity']),
                                "day_number": int(qi.get('day_number', 1)),
                                "start_time": str(qi.get('start_time', '09:00'))
                            })
                            
                        st.session_state.order_items = loaded_items
                        st.session_state.order_step = 2 # Jump to Add Services
                        st.rerun()
                        
                    st.divider()

                # Editable Fields
                c1, c2, c3 = st.columns(3)
                
                # S1. Status: Initialize state if missing to avoid conflict
                stat_key = f"stat_{row['order_id']}"
                if stat_key not in st.session_state:
                     # Default to current row status if valid, else first option
                     valid_stats = ["Confirmed", "Pending", "Completed", "Cancelled", "Quote"]
                     st.session_state[stat_key] = row['status'] if row['status'] in valid_stats else "Confirmed"
                
                new_status = c1.selectbox("Status", ["Confirmed", "Pending", "Completed", "Cancelled", "Quote"], 
                                         key=stat_key)
                
                
                # S2. Deposit: Initialize state if missing
                dep_key = f"dep_{row['order_id']}"
                if dep_key not in st.session_state:
                    st.session_state[dep_key] = float(row['deposit_paid'])
                    
                new_deposit = c2.number_input("Deposit Paid", key=dep_key, max_value=float(row['total_revenue']))
                
                # Notes Field
                current_notes = row.get('notes') if pd.notna(row.get('notes')) else ""
                new_notes = c3.text_area("Order Notes", value=str(current_notes), height=100, key=f"notes_{row['order_id']}")
                
                if st.button("Save Changes", key=f"save_{row['order_id']}"):
                    updates = {
                        "status": new_status,
                        "deposit_paid": new_deposit,
                        "balance_due": float(row['total_revenue']) - new_deposit,
                        "notes": new_notes
                    }
                    if dm.update_record("ORDER_HEADER", row['order_id'], updates):
                        success_toast("Order Updated")
                        st.rerun()

                # Actions
                a1, a2, a3 = st.columns(3)
                
                # Payment Popover
                with a1.popover("💰 Add Payment"):
                    p_amount = st.number_input("Amount", min_value=0.0, step=50.0, key=f"pay_amt_{row['order_id']}")
                    st.button("Record Payment", 
                              key=f"pay_btn_{row['order_id']}",
                              on_click=add_payment_callback,
                              args=(row['order_id'], p_amount, row['deposit_paid'], row['total_revenue']))

                # Print View
                if a2.button("🖨️ Print View", key=f"print_{row['order_id']}"):
                     # Simple Print View using Markdown
                     items_data = dm.load_data("ORDER_ITEM")
                     o_items = items_data[items_data['order_id'] == row['order_id']]
                     
                     st.session_state.print_order = {
                         "header": row,
                         "items": o_items
                     }
                     st.rerun()

                # Invoice Popover with Currency
                with a3.popover("📄 Download Invoice"):
                    st.write("Select Format:")
                    
                    # Currency Selection
                    curr_rates = dm.load_data("CURRENCY_RATE")
                    curr_opts = ["EGP"] + curr_rates['currency_code'].tolist()
                    sel_curr = st.selectbox("Currency", curr_opts, key=f"inv_curr_{row['order_id']}")
                    
                    rate = 1.0
                    if sel_curr != "EGP":
                        r_row = curr_rates[curr_rates['currency_code'] == sel_curr]
                        if not r_row.empty:
                            rate = float(r_row.iloc[0]['rate_to_egp'])
                    
                    # Fetch Data for generation
                    cust_data = dm.load_data("CUSTOMER")
                    cust_row = cust_data[cust_data['customer_id'] == row['customer_id']].iloc[0] if not cust_data.empty else {}
                    
                    items_data = dm.load_data("ORDER_ITEM")
                    order_items = items_data[items_data['order_id'] == row['order_id']]
                    
                    # 1. Detailed
                    pdf_det = ig.generate_pdf(row['order_id'], cust_row, row, order_items, detailed=True, currency_code=sel_curr, exchange_rate=rate)
                    st.download_button(
                        label=f"📝 Detailed ({sel_curr})",
                        data=pdf_det,
                        file_name=f"Invoice_Detailed_{row['order_id']}_{sel_curr}.pdf",
                        mime="application/pdf",
                        key=f"dl_det_{row['order_id']}",
                        use_container_width=True
                    )
                    
                    # 2. Summary
                    pdf_sum = ig.generate_pdf(row['order_id'], cust_row, row, order_items, detailed=False, currency_code=sel_curr, exchange_rate=rate)
                    st.download_button(
                        label=f"📋 Summary ({sel_curr})",
                        data=pdf_sum,
                        file_name=f"Invoice_Summary_{row['order_id']}_{sel_curr}.pdf",
                        mime="application/pdf",
                        key=f"dl_sum_{row['order_id']}",
                        use_container_width=True
                    )

                # Duplicate Action
                if st.button("©️ Duplicate as Quote", key=f"dup_{row['order_id']}"):
                    success, msg = dm.duplicate_order(row['order_id'])
                    if success:
                        success_toast(f"Duplicated to {msg}")
                        st.rerun()
                    else:
                        st.error(msg)

                st.divider()

                # --- ITINERARY BUILDER ---
                st.markdown("#### 📋 Trip Itinerary (行程表)")

                # Check summary
                all_itn = dm.load_data("ITINERARY")
                order_itn_count = 0
                if not all_itn.empty:
                    order_itn_count = len(all_itn[all_itn['order_id'] == row['order_id']])
                
                if order_itn_count > 0:
                     st.info(f"**{order_itn_count}** Entries created.")
                else:
                     st.caption("No itinerary entries yet.")
                
                if st.button("✏️ Open Itinerary Builder", key=f"open_itn_{row['order_id']}", use_container_width=True):
                    st.session_state['itinerary_order_id'] = row['order_id']
                    st.switch_page("pages/6_Itinerary_Detail.py")


                # Delete (Only if Cancelled or Pending)
                if row['status'] in ["Cancelled", "Pending"]:
                    with a2.popover("🗑️ Delete"):
                        st.warning("This cannot be undone.")
                        if st.button("Confirm Delete", key=f"del_{row['order_id']}"):
                            dm.delete_record("ORDER_HEADER", row['order_id'])
                            success_toast("Order Deleted")
                            st.rerun()
