import streamlit as st
import pandas as pd
import sys
import os
import time
from datetime import datetime

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from modules.data_manager import DataManager
from modules.logistics import LogisticsManager
from modules.invoice_generator import InvoiceGenerator

st.set_page_config(page_title="Customer Portal", page_icon="👋", layout="wide")

dm = DataManager()
lm = LogisticsManager()
ig = InvoiceGenerator()

# --- CSS for Portal Look ---
st.markdown("""
<style>
    .portal-card {
        padding: 20px;
        background-color: #f0f2f6;
        border-radius: 10px;
        margin-bottom: 20px;
    }
    .stButton>button {
        width: 100%;
    }
</style>
""", unsafe_allow_html=True)

# Session State for Login
if "portal_customer_id" not in st.session_state:
    st.session_state.portal_customer_id = None
if "portal_order_id" not in st.session_state:
    st.session_state.portal_order_id = None

# ==========================
# LOGIN SCREEN
# ==========================
if not st.session_state.portal_customer_id:
    c1, c2, c3 = st.columns([1, 2, 1])
    with c2:
        st.title("👋 Welcome to Your Trip Portal")
        st.markdown("Please verify your identity to view your itinerary and documents.")
        
        with st.container(border=True):
            order_input = st.text_input("Order ID (e.g., ORD-2026-001)")
            
            if st.button("🔓 Access Portal", type="primary"):
                if order_input:
                    # 1. Check Order Exists
                    orders = dm.load_data("ORDER_HEADER")
                    trip = orders[orders['order_id'] == order_input]
                    
                    if not trip.empty:
                        cust_id = trip.iloc[0]['customer_id']
                        
                        # Direct Access without identity check
                        st.session_state.portal_customer_id = cust_id
                        st.session_state.portal_order_id = order_input
                        st.success("Loading portal...")
                        time.sleep(1)
                        st.rerun()
                    else:
                        st.error("Order ID not found.")
                else:
                    st.warning("Please enter Order ID.")

else:
    # ==========================
    # LOGGED IN DASHBOARD
    # ==========================
    
    # Reload Data
    oid = st.session_state.portal_order_id
    orders = dm.load_data("ORDER_HEADER")
    trip = orders[orders['order_id'] == oid].iloc[0]
    
    customers = dm.load_data("CUSTOMER")
    me = customers[customers['customer_id'] == st.session_state.portal_customer_id].iloc[0]
    
    # Header
    c_head1, c_head2 = st.columns([3, 1])
    c_head1.title(f"Trip to {trip.get('destination', 'Your Destination')}") # Dest not in schema but maybe inferred? Just generic header
    c_head1.title(f"✈️ Your Trip Details")
    c_head1.caption(f"Order #{oid} | Status: {trip['status']}")
    
    if c_head2.button("🔒 Logout"):
        st.session_state.portal_customer_id = None
        st.session_state.portal_order_id = None
        st.rerun()
        
    st.divider()
    
    # 1. HEADLINES
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Trip Start", pd.to_datetime(trip['trip_start_date']).strftime('%b %d, %Y'))
    m2.metric("Trip End", pd.to_datetime(trip['trip_end_date']).strftime('%b %d, %Y'))
    m3.metric("Travelers", trip['pax_count'])
    bal = float(trip['balance_due'])
    m4.metric("Balance Due", f"${bal:,.2f}", delta="Paid" if bal <= 0 else "Outstanding", delta_color="inverse" if bal > 0 else "normal")
    
    st.divider()
    
    # 2. ITINERARY
    col_itin, col_docs = st.columns([2, 1])
    
    with col_itin:
        st.subheader("📅 Your Itinerary")
        
        items_db = dm.load_data("ORDER_ITEM")
        my_items = items_db[items_db['order_id'] == oid]
        
        # Merge service names to fix KeyError and avoid SettingWithCopyWarning
        services = dm.load_data("SERVICE_PRODUCT")
        if not services.empty and not my_items.empty:
            my_items = my_items.merge(
                services[['service_id', 'service_name']],
                on='service_id',
                how='left'
            )
            # Fill missing names
            my_items['service_name'] = my_items['service_name'].fillna("Unknown Service")
        elif 'service_name' not in my_items.columns:
            my_items['service_name'] = "Unknown Service"
            
        if not my_items.empty:
            timeline = lm.generate_itinerary_timeline(pd.to_datetime(trip['trip_start_date']), my_items)
            
            for day_grp in timeline:
                with st.expander(f"Day {day_grp['day']}: {day_grp['date']}", expanded=True):
                    for item in day_grp['items']:
                        st.markdown(f"**{item.get('start_time', '09:00')}** - {item['service_name']}")
                        st.caption(f"Qty: {item['quantity']}")
        else:
            st.info("No itinerary items found.")
            
    with col_docs:
        st.subheader("📂 Documents & Actions")
        
        with st.container(border=True):
            st.markdown("#### 📄 Invoice / Receipt")
            if st.button("Download latest Invoice PDF"):
                pdf_bytes = ig.generate_pdf(oid, me, trip, my_items)
                st.download_button(
                    label="📥 Click to Download",
                    data=pdf_bytes,
                    file_name=f"Trip_Invoice_{oid}.pdf",
                    mime="application/pdf"
                )
                
            st.markdown("#### 🗓️ Trip Itinerary")
            if st.button("Download Itinerary PDF"):
                pdf_bytes = ig.generate_itinerary_pdf(oid, me, trip, my_items)
                st.download_button(
                    label="📥 Click to Download Itinerary",
                    data=pdf_bytes,
                    file_name=f"Itinerary_{oid}.pdf",
                    mime="application/pdf"
                )
        
        with st.container(border=True):
            st.markdown("#### 📞 Support")
            st.write(f"Need help? Contact us.")
            st.info("contact@travelagency.com\n\n+1 (555) 123-4567")

    # 3. NOTES
    if trip.get('notes'):
        st.divider()
        st.subheader("📝 Important Notes")
        st.info(trip['notes'])
