import streamlit as st
import sys
import os
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from modules.data_manager import DataManager

st.set_page_config(page_title="Financial Reports", layout="wide", page_icon="📈")
dm = DataManager()

from modules.ui_components import render_header

render_header("Financial Intelligence Center", "📈")

# --- DATA LOADING & PREP ---
orders = dm.load_data("ORDER_HEADER")
order_items = dm.load_data("ORDER_ITEM")
customers = dm.load_data("CUSTOMER")
services = dm.load_data("SERVICE_PRODUCT")

if orders.empty:
    st.warning("No order data available yet.")
    st.stop()

# Ensure types
orders['trip_start_date'] = pd.to_datetime(orders['trip_start_date'])
orders['total_revenue'] = pd.to_numeric(orders['total_revenue'], errors='coerce').fillna(0)
orders['total_profit'] = pd.to_numeric(orders['total_profit'], errors='coerce').fillna(0)

# --- SIDEBAR FILTERS ---
st.sidebar.header("Filter Reports")
date_range = st.sidebar.date_input(
    "Date Range",
    value=(orders['trip_start_date'].min().date(), datetime.now().date() + timedelta(days=30))
)

if len(date_range) == 2:
    start_d, end_d = date_range
    mask = (orders['trip_start_date'].dt.date >= start_d) & (orders['trip_start_date'].dt.date <= end_d)
    filtered_orders = orders.loc[mask]
else:
    filtered_orders = orders

# --- KPIS ---
kpi1, kpi2, kpi3, kpi4 = st.columns(4)
total_rev = filtered_orders['total_revenue'].sum()
total_prof = filtered_orders['total_profit'].sum()
margin = (total_prof / total_rev * 100) if total_rev > 0 else 0
outstanding = filtered_orders['balance_due'].sum()

with kpi1:
    st.metric("Total Revenue", f"${total_rev:,.2f}", delta="Gross Sales")
with kpi2:
    st.metric("Net Profit", f"${total_prof:,.2f}", delta=f"{margin:.1f}% Margin")
with kpi3:
    st.metric("Orders Count", len(filtered_orders))
with kpi4:
    st.metric("Accounts Receivable", f"${outstanding:,.2f}", delta_color="inverse")

st.divider()

# --- CHARTS ---
tab1, tab2, tab3 = st.tabs(["📊 Profitability", "🏆 Customer Ranking", "📦 Service Performance"])

with tab1:
    col_c1, col_c2 = st.columns([2, 1])
    
    with col_c1:
        # Monthly Trend
        filtered_orders['Month'] = filtered_orders['trip_start_date'].dt.strftime('%Y-%m')
        monthly = filtered_orders.groupby('Month')[['total_revenue', 'total_profit']].sum().reset_index()
        
        fig = go.Figure()
        fig.add_trace(go.Bar(x=monthly['Month'], y=monthly['total_revenue'], name='Revenue', marker_color='#88c0d0'))
        fig.add_trace(go.Bar(x=monthly['Month'], y=monthly['total_profit'], name='Profit', marker_color='#a3be8c'))
        fig.update_layout(title="Monthly Revenue vs Profit", barmode='group')
        st.plotly_chart(fig, width='stretch')
        
    with col_c2:
        # Order Status Distribution
        status_dist = filtered_orders['status'].value_counts().reset_index()
        fig2 = px.pie(status_dist, values='count', names='status', title="Order Status Breakdown", hole=0.4)
        st.plotly_chart(fig2, width='stretch')

with tab2:
    # Customer Revenue
    if not customers.empty:
        cust_rev = filtered_orders.groupby('customer_id')['total_revenue'].sum().reset_index()
        cust_rev = cust_rev.merge(customers[['customer_id', 'name']], on='customer_id', how='left')
        cust_rev = cust_rev.sort_values('total_revenue', ascending=False).head(10)
        
        st.subheader("Top 10 Customers by Revenue")
        st.dataframe(
            cust_rev, 
            column_config={
                "total_revenue": st.column_config.ProgressColumn("Revenue Contribution", format="$%.2f", min_value=0, max_value=float(cust_rev['total_revenue'].max()))
            },
            hide_index=True,
            width='stretch'
        )

with tab3:
    # Service Analysis requires joining items with headers to filter by date
    # Filter items based on filtered orders
    relevant_order_ids = filtered_orders['order_id'].tolist()
    rel_items = order_items[order_items['order_id'].isin(relevant_order_ids)]
    
    # Needs service names
    if not rel_items.empty and not services.empty:
        # Rel Items has 'service_id', join with services
        svc_perf = rel_items.groupby('service_id').agg({
            'quantity': 'sum',
            'selling_price': 'sum' # Approximation of total revenue per service
        }).reset_index()
        
        svc_perf = svc_perf.merge(services[['service_id', 'service_name', 'service_type']], on='service_id', how='left')
        svc_perf = svc_perf.rename(columns={'selling_price': 'Total Revenue', 'quantity': 'Units Sold'})
        
        # Clean Data for Sunburst
        svc_perf['service_type'] = svc_perf['service_type'].fillna('Unknown Type').replace('', 'Unknown Type')
        svc_perf['service_name'] = svc_perf['service_name'].fillna('Unknown Service').replace('', 'Unknown Service')
        
        st.subheader("Top Services")
        try:
             fig3 = px.sunburst(svc_perf, path=['service_type', 'service_name'], values='Total Revenue', title="Revenue by Service Type")
             st.plotly_chart(fig3, width='stretch')
        except Exception as e:
             st.error(f"Could not generate chart: {e}")
        
        st.dataframe(svc_perf.sort_values('Total Revenue', ascending=False), hide_index=True)
    else:
        st.info("No service item data available within range.")

# --- EXPORT ---
st.divider()
c_ex1, c_ex2 = st.columns([4, 1])
with c_ex2:
    if st.button("📥 Export Financial Report"):
        csv = filtered_orders.to_csv(index=False).encode('utf-8')
        st.download_button(
            label="Download CSV",
            data=csv,
            file_name="Financial_Report.csv",
            mime="text/csv"
        )
