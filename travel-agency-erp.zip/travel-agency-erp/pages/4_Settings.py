import streamlit as st
import sys
import os
import pandas as pd
import time
from datetime import datetime

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from modules.data_manager import DataManager
from modules.validators import validate_customer, validate_vendor

st.set_page_config(page_title="Settings & CRM", layout="wide", page_icon="⚙️")
dm = DataManager()

# --- HELPER FUNCTIONS ---
def success_toast(msg):
    st.toast(msg, icon="✅")
    time.sleep(0.5)

def error_toast(msg):
    st.toast(msg, icon="❌")

def delete_handler(table, id_val):
    if dm.delete_record(table, id_val):
        success_toast(f"Record {id_val} Deleted")
        st.rerun()
    else:
        error_toast("Delete Failed")

from modules.ui_components import render_header

# --- MAIN PAGE ---
render_header("System Settings & Data", "⚙️")

tab1, tab2, tab3, tab4 = st.tabs(["👥 Customers (CRM)", "🏢 Vendors", "💱 Currency Rates", "🛠️ System Admin"])

# ==========================
# TAB 1: CUSTOMERS
# ==========================
with tab1:
    c1, c2 = st.columns([3, 1])
    with c1:
        cust_search = st.text_input("🔍 Search Customers", placeholder="Name, Phone, Email...")
    with c2:
        add_cust_btn = st.button("➕ Add Customer", width='stretch')

    # ADD CUSTOMER FORM
    if add_cust_btn or st.session_state.get("show_add_cust", False):
        st.session_state.show_add_cust = True
        with st.expander("New Customer Profile", expanded=True):
            with st.form("add_cus_form"):
                cc1, cc2 = st.columns(2)
                name = cc1.text_input("Full Name")
                priority = cc2.selectbox("Priority", ["Standard", "VIP", "Corporate"])
                
                cc3, cc4 = st.columns(2)
                phone = cc3.text_input("Phone")
                email = cc4.text_input("Email")
                
                cc5, cc6 = st.columns(2)
                wechat = cc5.text_input("WeChat ID")
                nationality = cc6.text_input("Nationality")
                
                channel = st.selectbox("Acquisition Channel", ["Direct", "Referral", "Web", "Xiaohongshu", "Agency", "Other"])

                if st.form_submit_button("Save Customer"):
                    new_cus = {
                        "name": name,
                        "phone": phone,
                        "email": email,
                        "wechat_id": wechat,
                        "nationality": nationality,
                        "channel": channel,
                        "priority": priority,
                        "number_of_orders": 0
                    }
                    val, msg = validate_customer(new_cus)
                    if val:
                        dm.add_record("CUSTOMER", new_cus)
                        success_toast("Customer Added")
                        st.session_state.show_add_cust = False
                        st.rerun()
                    else:
                        error_toast(msg)

    st.divider()
    
    # LOAD & EDIT CUSTOMERS
    if cust_search:
        df_cus = dm.search_records("CUSTOMER", cust_search)
    else:
        df_cus = dm.load_data("CUSTOMER")
    
    # Validation Code for Data Editor (Fixes nationality mixed types)
    if not df_cus.empty and 'nationality' in df_cus.columns:
        df_cus['nationality'] = df_cus['nationality'].fillna("").astype(str)

    if not df_cus.empty:
        st.subheader(f"Customer List ({len(df_cus)})")
        
        edited_cus = st.data_editor(
            df_cus,
            column_config={
                "customer_id": st.column_config.TextColumn("ID", disabled=True),
                "nationality": st.column_config.TextColumn("Nationality"),
                "channel": st.column_config.SelectboxColumn("Channel", options=["Direct", "Referral", "Web", "Xiaohongshu", "Agency", "Other"]),
                "number_of_orders": st.column_config.NumberColumn("Orders", disabled=True),
                "priority": st.column_config.SelectboxColumn("Tier", options=["Standard", "VIP", "Corporate"]),
            },
            hide_index=True,
            width='stretch',
            key="cus_editor"
        )
        
        col_act1, col_act2 = st.columns(2)
        with col_act1:
            if st.button("💾 Save Changes", key="save_cus"):
                if dm.save_data("CUSTOMER", edited_cus):
                    success_toast("Customer Data Updated")
                    st.rerun()
                else:
                    error_toast("Update Failed")
        
        with col_act2:
            with st.popover("🗑️ Delete Customer"):
                del_id = st.selectbox("Select to Delete", df_cus['customer_id'].tolist(), key="del_cus_sel")
                if st.button("Confirm Delete", key="del_cus_btn"):
                    delete_handler("CUSTOMER", del_id)
    else:
        st.info("No customers found.")

    st.divider()
    
    # CUSTOMER HISTORY
    st.subheader("📜 Customer History")
    
    # Select Customer for History
    if not df_cus.empty:
        hist_cust_name = st.selectbox("Select Customer to View History", df_cus['name'].tolist(), key="hist_sel")
        
        if hist_cust_name:
            # Get ID
            c_row = df_cus[df_cus['name'] == hist_cust_name].iloc[0]
            c_id = c_row['customer_id']
            
            # Load Orders
            all_orders = dm.load_data("ORDER_HEADER")
            cust_orders = all_orders[all_orders['customer_id'] == c_id].copy()
            
            if not cust_orders.empty:
                # Calculate LTV (Lifetime Value) - excluding Quotes
                real_orders = cust_orders[cust_orders['status'] != 'Quote']
                ltv = pd.to_numeric(real_orders['total_revenue'], errors='coerce').sum()
                
                # Metrics
                hm1, hm2, hm3 = st.columns(3)
                hm1.metric("Lifetime Value (LTV)", f"LE {ltv:,.2f}")
                hm2.metric("Total Orders", len(real_orders))
                hm3.metric("Last Active", pd.to_datetime(cust_orders['trip_start_date']).max().strftime('%Y-%m-%d') if not cust_orders.empty else "N/A")
                
                # Display Table
                st.dataframe(
                    cust_orders[['order_id', 'status', 'trip_start_date', 'total_revenue', 'balance_due']],
                    column_config={
                        "total_revenue": st.column_config.NumberColumn("Amount", format="LE %.2f"),
                        "balance_due": st.column_config.NumberColumn("Balance", format="LE %.2f"),
                        "trip_start_date": st.column_config.DateColumn("Trip Date")
                    },
                    hide_index=True,
                    width='stretch'
                )
            else:
                st.info(f"No order history found for {hist_cust_name}.")

# ==========================
# TAB 2: VENDORS
# ==========================
with tab2:
    v1, v2 = st.columns([3, 1])
    with v1:
        ven_search = st.text_input("🔍 Search Vendors", placeholder="Name, Type, Contact...")
    with v2:
        add_ven_btn = st.button("➕ Add Vendor", width='stretch')

    # ADD VENDOR FORM
    if add_ven_btn or st.session_state.get("show_add_ven", False):
        st.session_state.show_add_ven = True
        with st.expander("New Vendor Profile", expanded=True):
            with st.form("add_ven_form"):
                vc1, vc2 = st.columns(2)
                v_name = vc1.text_input("Entity Name")
                v_type = vc2.selectbox("Type", ["Driver", "Hotel", "Agency", "Guide", "Other"])
                
                vc3, vc4 = st.columns(2)
                v_contact = vc3.text_input("Contact Number")
                v_person = vc4.text_input("Contact Person")
                
                v_pay = st.text_input("Payment Terms", value="Net 30")
                
                if st.form_submit_button("Save Vendor"):
                    new_ven = {
                        "vendor_name": v_name,
                        "vendor_type": v_type,
                        "contact_number": v_contact,
                        "person_name": v_person,
                        "payment_terms": v_pay
                    }
                    val, msg = validate_vendor(new_ven)
                    if val:
                        dm.add_record("VENDOR", new_ven)
                        success_toast("Vendor Added")
                        st.session_state.show_add_ven = False
                        st.rerun()
                    else:
                        error_toast(msg)
    
    st.divider()

    # LOAD & EDIT VENDORS
    if ven_search:
        df_ven = dm.search_records("VENDOR", ven_search)
    else:
        df_ven = dm.load_data("VENDOR")

    if not df_ven.empty:
        st.subheader(f"Vendor List ({len(df_ven)})")
        
        edited_ven = st.data_editor(
            df_ven,
            column_config={
                "vendor_id": st.column_config.TextColumn("ID", disabled=True),
                "vendor_type": st.column_config.SelectboxColumn("Type", options=["Driver", "Hotel", "Agency", "Guide", "Other"]),
            },
            hide_index=True,
            width='stretch',
            key="ven_editor"
        )
        
        vc_act1, vc_act2 = st.columns(2)
        with vc_act1:
            if st.button("💾 Save Changes", key="save_ven"):
                if dm.save_data("VENDOR", edited_ven):
                    success_toast("Vendor Data Updated")
                    st.rerun()
                else:
                    error_toast("Update Failed")
                    
        with vc_act2:
            with st.popover("🗑️ Delete Vendor"):
                del_vid = st.selectbox("Select to Delete", df_ven['vendor_id'].tolist(), key="del_ven_sel")
                if st.button("Confirm Delete", key="del_ven_btn"):
                    delete_handler("VENDOR", del_vid)
    else:
        st.info("No vendors found.")

# ==========================
# TAB 3: ADMIN
# ==========================
# ==========================
# TAB 3: CURRENCY RATES
# ==========================
with tab3:
    st.subheader("💱 Exchange Rates Support")

    # Load Currencies
    curr_df = dm.load_data("CURRENCY_RATE")
    
    # Defaults Check
    if curr_df.empty:
        defaults = [
            {"currency_code": "USD", "currency_name": "US Dollar", "rate_to_egp": 50.50, "last_updated": datetime.now().strftime("%Y-%m-%d")},
            {"currency_code": "CNY", "currency_name": "Chinese Yuan", "rate_to_egp": 7.00, "last_updated": datetime.now().strftime("%Y-%m-%d")},
            {"currency_code": "EUR", "currency_name": "Euro", "rate_to_egp": 54.20, "last_updated": datetime.now().strftime("%Y-%m-%d")}
        ]
        for d in defaults:
            dm.add_record("CURRENCY_RATE", d)
        st.rerun()

    # Layout
    col_base, col_list = st.columns([1, 3])
    
    with col_base:
        st.info("ℹ️ Base Currency: **EGP** (Egyptian Pound)")
        st.caption("All 'Rate' values should be entered as: How many EGP is 1 Unit of Foreign Currency?")
        st.caption("Example: 1 USD = 50.5 EGP")
        
        with st.form("add_curr"):
            st.markdown("#### Add Currency")
            nc_code = st.text_input("Code (e.g. GBP)").upper()
            nc_name = st.text_input("Name (e.g. British Pound)")
            nc_rate = st.number_input("Rate to EGP", min_value=0.01, step=0.01)
            
            if st.form_submit_button("Add New"):
                if nc_code and nc_name:
                    new_curr = {
                        "currency_code": nc_code,
                        "currency_name": nc_name,
                        "rate_to_egp": nc_rate,
                        "last_updated": datetime.now().strftime("%Y-%m-%d")
                    }
                    dm.add_record("CURRENCY_RATE", new_curr)
                    success_toast(f"{nc_code} Added")
                    st.rerun()
                else:
                    error_toast("Missing fields")

    with col_list:
        st.markdown("### Current Exchange Rates")
        
        edited_rates = st.data_editor(
            curr_df,
            column_config={
                "currency_code": st.column_config.TextColumn("Code", disabled=True),
                "currency_name": st.column_config.TextColumn("Name"),
                "rate_to_egp": st.column_config.NumberColumn("Rate (1 Unit = X EGP)", format="%.4f"),
                "last_updated": st.column_config.TextColumn("Last Updated", disabled=True)
            },
            hide_index=True,
            width='stretch',
            key="rate_editor"
        )
        
        c_act1, c_act2 = st.columns(2)
        with c_act1:
            if st.button("💾 Save Rates", key="save_rates"):
                # Update timestamp for modified
                # Simple logic: just update all timestamps on save for simplicity, or keep old if not logic strictly needed
                # For now just save
                if dm.save_data("CURRENCY_RATE", edited_rates):
                    success_toast("Rates Updated")
                    st.rerun()
                    
        with c_act2:
             with st.popover("🗑️ Delete Currency"):
                del_code = st.selectbox("Select to Delete", curr_df['currency_code'].tolist())
                if st.button("Confirm Delete", key="del_curr_btn"):
                    # Custom delete since PK is currency_code in logic but generate_id logic might be irrelevant here as we used valid codes
                    # Wait, dm.delete_record expects PK value. 
                    # CURRENCY_RATE schema: ["currency_code", ...] - so code is PK.
                    if dm.delete_record("CURRENCY_RATE", del_code):
                        success_toast("Deleted")
                        st.rerun()

# ==========================
# TAB 4: ADMIN
# ==========================
with tab4:
    st.subheader("Data Management")
    
    c1, c2 = st.columns(2)
    with c1:
        st.markdown("### 💾 Backup Data")
        st.info("Creates a timestamped copy of all Excel databases.")
        if st.button("Run Full Backup"):
            tables = ["CUSTOMER", "VENDOR", "SERVICE_PRODUCT", "LOCATION", "ORDER_HEADER", "ORDER_ITEM", "ITINERARY", "CURRENCY_RATE"]
            success = True
            for t in tables:
                if not dm.backup_table(t):
                    success = False
            
            if success:
                st.success("All tables backed up successfully to /data/backups/")
            else:
                st.warning("Some backups may have failed. Check console.")
                
    with c2:
        st.markdown("### 📤 Export Data")
        st.info("Download current data as CSV.")
        export_table = st.selectbox("Select Table", dm.SCHEMAS.keys())
        if st.button("Prepare Export"):
            df = dm.load_data(export_table)
            csv = df.to_csv(index=False).encode('utf-8')
            st.download_button(
                label=f"Download {export_table}.csv",
                data=csv,
                file_name=f"{export_table}.csv",
                mime="text/csv"
            )
