import pandas as pd
from fpdf import FPDF
import io
import os
from datetime import datetime

class ItineraryExporter:
    def __init__(self):
        pass

    def generate_excel(self, itinerary_df):
        """
        Generates an Excel file matching the customer's format using openpyxl.
        """
        if itinerary_df.empty:
            return None

        # Prepare Data
        export_data = []
        for _, row in itinerary_df.iterrows():
            # Format Date
            date_obj = pd.to_datetime(row['date'])
            date_str = f"{date_obj.month}月{date_obj.day}日"
            
            # Format Time
            time_str = ""
            start_t = row.get('start_time')
            end_t = row.get('end_time')
            
            if pd.notna(start_t) and str(start_t).strip() and str(start_t).lower() != 'nan':
                time_str = str(start_t)[:5]
                if pd.notna(end_t) and str(end_t).strip() and str(end_t).lower() != 'nan':
                    time_str += f"–{str(end_t)[:5]}"
            
            export_data.append({
                "日期": date_str,
                "时间": time_str,
                "城市": row.get('city_route', ''),
                "具体安排": row.get('activity', ''),
                "备注 / 交通": row.get('notes', ''),
                "住宿": row.get('accommodation', '')
            })
            
        df_out = pd.DataFrame(export_data)
        
        # Create Excel
        output = io.BytesIO()
        try:
            with pd.ExcelWriter(output, engine='openpyxl') as writer:
                sheet_name = 'Egypt Trip - Time Schedule'
                df_out.to_excel(writer, sheet_name=sheet_name, index=False)
                
                # Get Access to Sheet
                worksheet = writer.sheets[sheet_name]
                
                # Import styles
                from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
                
                # Define Styles
                thin = Side(border_style="thin", color="000000")
                border = Border(top=thin, left=thin, right=thin, bottom=thin)
                
                header_font = Font(bold=True)
                header_fill = PatternFill(start_color="D7E4BC", end_color="D7E4BC", fill_type="solid")
                align_top = Alignment(vertical='top', wrap_text=True)
                
                # Apply Column Dimensions
                worksheet.column_dimensions['A'].width = 12 # Date
                worksheet.column_dimensions['B'].width = 18 # Time
                worksheet.column_dimensions['C'].width = 25 # City
                worksheet.column_dimensions['D'].width = 50 # Activity
                worksheet.column_dimensions['E'].width = 30 # Notes
                worksheet.column_dimensions['F'].width = 30 # Accom

                # Iterate and format
                for row_idx, row in enumerate(worksheet.iter_rows()):
                    is_header = (row_idx == 0)
                    for cell in row:
                        cell.alignment = align_top
                        cell.border = border
                        if is_header:
                            cell.font = header_font
                            cell.fill = header_fill

        except Exception as e:
            print(f"Excel Export Error: {e}")
            return None
            
        return output.getvalue()

    def generate_pdf(self, order_id, itinerary_df):
        """
        Generates a professionally formatted PDF itinerary.
        """
        if itinerary_df.empty:
            return None
            
        class PDF(FPDF):
            def header(self):
                self.set_font('Arial', 'B', 16)
                self.cell(0, 10, f'Trip Itinerary - Order {order_id}', 0, 1, 'C')
                self.ln(5)
                
            def footer(self):
                self.set_y(-15)
                self.set_font('Arial', 'I', 8)
                self.cell(0, 10, f'Page {self.page_no()}', 0, 0, 'C')

        pdf = PDF(orientation='L', unit='mm', format='A4') # Landscape for more space
        pdf.set_auto_page_break(auto=True, margin=15)
        pdf.add_page()
        
        # Table Header
        pdf.set_font('Arial', 'B', 10)
        cols = [25, 30, 40, 80, 50, 50] # Widths
        headers = ["Date", "Time", "Route/City", "Activity", "Notes", "Accommodation"]
        
        # Draw Header
        for i, h in enumerate(headers):
            pdf.cell(cols[i], 10, h, 1, 0, 'C')
        pdf.ln()
        
        # Table Content
        pdf.set_font('Arial', '', 9)
        
        for _, row in itinerary_df.iterrows():
             # Format Data
            date_obj = pd.to_datetime(row['date'])
            date_str = date_obj.strftime("%b %d")
            
            time_str = ""
            start_t = row.get('start_time')
            end_t = row.get('end_time')
            if pd.notna(start_t) and str(start_t).strip() and str(start_t).lower() != 'nan':
                time_str = str(start_t)[:5]
                if pd.notna(end_t) and str(end_t).strip() and str(end_t).lower() != 'nan':
                    time_str += f"-{str(end_t)[:5]}"
            
            # Wrapper to clean text (Latin-1 is limited, so we strip non-latin chars effectively or replace)
            def clean(txt):
                if pd.isna(txt): return ""
                # Simple cleaning: remove non-ascii/latin-1 friendly chars to prevent crashes, 
                # but try to keep text. ideally we use a unicode font but FPDF default is limited.
                # Let's just strip emojis/unsupported chars by encoding/decoding
                txt = str(txt)
                try:
                    return txt.encode('latin-1', 'replace').decode('latin-1')
                except:
                    return txt.encode('ascii', 'ignore').decode('ascii')

            # Basic row print - Increased limits
            # Note: MultiCell would be better for wrapping but requires calculating max height for the whole row (all cells)
            # which is complex in simple FPDF. For now, just truncating less.
            pdf.cell(cols[0], 10, clean(date_str), 1)
            pdf.cell(cols[1], 10, clean(time_str), 1)
            pdf.cell(cols[2], 10, clean(str(row.get('city_route', '')))[:25], 1) 
            pdf.cell(cols[3], 10, clean(str(row.get('activity', '')))[:60], 1) # Increased from 45
            pdf.cell(cols[4], 10, clean(str(row.get('notes', '')))[:60], 1)    # Increased from 25
            pdf.cell(cols[5], 10, clean(str(row.get('accommodation', '')))[:30], 1)
            pdf.ln()

        return pdf.output(dest='S').encode('latin-1')
