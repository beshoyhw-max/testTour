import pandas as pd
import os
import shutil
from datetime import datetime
import time

DATA_DIR = os.path.join(os.getcwd(), "data")

# Database Schemas
SCHEMAS = {
    "CUSTOMER": ["customer_id", "name", "phone", "wechat_id", "email", "nationality", "priority", "channel", "number_of_orders"],
    "VENDOR": ["vendor_id", "vendor_name", "vendor_type", "contact_number", "person_name", "payment_terms"],
    "SERVICE_PRODUCT": ["service_id", "service_name", "service_type", "types", "city", "default_base_cost", "default_profit_margin_percent", "standard_selling_price", "is_favorite"],
    "LOCATION": ["location_id", "city", "attraction_name", "latitude", "longitude"],
    "ORDER_HEADER": ["order_id", "customer_id", "trip_start_date", "trip_end_date", "pax_count", "status", "total_cost", "total_revenue", "total_profit", "deposit_paid", "balance_due", "notes"],
    "ORDER_ITEM": ["item_id", "order_id", "service_id", "vendor_id", "quantity", "actual_cost", "profit_margin_percent", "selling_price", "day_number", "start_time", "location"],
    "PACKAGE_DEF": ["package_id", "package_name", "total_price", "description"],
    "PACKAGE_ITEMS": ["package_id", "service_id", "quantity"],
    "ITINERARY": ["entry_id", "order_id", "date", "start_time", "end_time", "city_route", "activity", "notes", "accommodation", "linked_item_id", "is_locked"],
    "CURRENCY_RATE": ["currency_code", "currency_name", "rate_to_egp", "last_updated"]
}

class DataManager:
    def __init__(self):
        self.SCHEMAS = SCHEMAS
        self._ensure_data_directory()
        self._initialize_db()

    def _ensure_data_directory(self):
        if not os.path.exists(DATA_DIR):
            os.makedirs(DATA_DIR)

    def _get_file_path(self, table_name):
        return os.path.join(DATA_DIR, f"{table_name}.xlsx")

    def _initialize_db(self):
        """Creates empty Excel files with headers if they don't exist."""
        for table, columns in SCHEMAS.items():
            path = self._get_file_path(table)
            if not os.path.exists(path):
                df = pd.DataFrame(columns=columns)
                df.to_excel(path, index=False)

    def load_data(self, table_name):
        """Reads data from Excel safely."""
        path = self._get_file_path(table_name)
        schema_cols = SCHEMAS.get(table_name, [])
        
        if os.path.exists(path):
            try:
                # Specify dtype=str for IDs to prevent auto-conversion
                df = pd.read_excel(path)
                
                # Ensure all schema columns exist (Migration for new columns)
                if schema_cols:
                    missing_cols = [c for c in schema_cols if c not in df.columns]
                    if missing_cols:
                        for c in missing_cols:
                            df[c] = None
                        # Optionally save back to fix file immediately? 
                        # Better to just return corrected DF and let save handle it eventually
                        
                return df
            except Exception as e:
                return pd.DataFrame(columns=schema_cols)
        return pd.DataFrame(columns=schema_cols)

    def save_data(self, table_name, df):
        """
        Atomic write operation:
        1. Write to temp file
        2. Replace original file
        """
        path = self._get_file_path(table_name)
        # Fix: Use .xlsx extension so pandas recognizes the file type
        temp_path = path + ".temp.xlsx"
        try:
            df.to_excel(temp_path, index=False, engine='openpyxl')
            if os.path.exists(path):
                os.remove(path)
            os.rename(temp_path, path)
            return True
        except Exception as e:
            print(f"Error saving {table_name}: {e}")
            if os.path.exists(temp_path):
                os.remove(temp_path)
            return False

    def add_record(self, table_name, record_dict):
        """Adds a single record to the database."""
        df = self.load_data(table_name)
        
        # Ensure ID generation
        pk_col = SCHEMAS[table_name][0]
        if not record_dict.get(pk_col):
            record_dict[pk_col] = self.generate_id(table_name)
            
        new_row = pd.DataFrame([record_dict])
        df = pd.concat([df, new_row], ignore_index=True)
        return self.save_data(table_name, df)

    def update_record(self, table_name, pk_value, updates_dict):
        """Updates a record based on Primary Key."""
        df = self.load_data(table_name)
        pk_col = SCHEMAS[table_name][0]
        
        if pk_value in df[pk_col].values:
            idx = df[df[pk_col] == pk_value].index
            for col, val in updates_dict.items():
                if col in df.columns:
                    df.loc[idx, col] = val
            return self.save_data(table_name, df)
        return False

    def delete_record(self, table_name, pk_value):
        """Deletes a record based on Primary Key."""
        df = self.load_data(table_name)
        pk_col = SCHEMAS[table_name][0]
        
        if pk_value in df[pk_col].values:
            df = df[df[pk_col] != pk_value]
            return self.save_data(table_name, df)
        return False

    def search_records(self, table_name, query, columns=None):
        """Searches records containing query string."""
        df = self.load_data(table_name)
        if df.empty or not query:
            return df
            
        if columns is None:
            columns = df.columns
            
        mask = pd.DataFrame(False, index=df.index, columns=df.columns)
        for col in columns:
            if col in df.columns:
                mask[col] = df[col].astype(str).str.contains(query, case=False, na=False)
                
        return df[mask.any(axis=1)]

    def backup_table(self, table_name):
        """Creates a timestamped backup of the table."""
        path = self._get_file_path(table_name)
        if os.path.exists(path):
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_name = f"{table_name}_BACKUP_{ts}.xlsx"
            backup_path = os.path.join(DATA_DIR, "backups", backup_name)
            
            # Ensure backup dir exists
            backup_dir = os.path.dirname(backup_path)
            if not os.path.exists(backup_dir):
                os.makedirs(backup_dir)
                
            try:
                shutil.copy2(path, backup_path)
                return True
            except Exception as e:
                print(f"Backup failed: {e}")
                return False
        return False

    def generate_id(self, table_name):
        """Generates readable IDs (e.g., CUS-001, ORD-2024-001)."""
        df = self.load_data(table_name)
        pk_col = SCHEMAS[table_name][0]
        
        prefix_map = {
            "CUSTOMER": "CUS",
            "VENDOR": "VEN",
            "SERVICE_PRODUCT": "SVC",
            "LOCATION": "LOC",
            "ORDER_HEADER": f"ORD-{datetime.now().year}",
            "ORDER_ITEM": "ITM",
            "PACKAGE_DEF": "PKG",
            "ITINERARY": "ITN",
            "CURRENCY_RATE": "CUR"
        }
        
        prefix = prefix_map.get(table_name, "GEN")
        
        if df.empty:
            next_num = 1
        else:
            # Extract numeric part from ID
            try:
                # Assuming format PREFIX-XXX...
                existing_ids = df[pk_col].astype(str).tolist()
                # Filter specific prefix for orders (yearly change)
                relevant_ids = [x for x in existing_ids if x.startswith(prefix)]
                if not relevant_ids:
                    next_num = 1
                else:
                    # Robust extraction: split by last hyphen and take the last part
                    # Handles flexible prefixes
                    max_id = 0
                    for rid in relevant_ids:
                        parts = rid.split('-')
                        if len(parts) > 1 and parts[-1].isdigit():
                            num = int(parts[-1])
                            if num > max_id:
                                max_id = num
                    next_num = max_id + 1
            except Exception as e:
                print(f"ID Generation Error: {e}")
                next_num = len(df) + 1

        return f"{prefix}-{next_num:03d}"

    def duplicate_order(self, original_order_id):
        """
        Creates a copy of an existing order with a new ID and 'Quote' status.
        """
        # 1. Get Original Header
        orders = self.load_data("ORDER_HEADER")
        orig_header = orders[orders['order_id'] == original_order_id]
        
        if orig_header.empty:
            return False, "Original order not found."
            
        # 2. Get Original Items
        items = self.load_data("ORDER_ITEM")
        orig_items = items[items['order_id'] == original_order_id]
        
        # 3. Create New Header
        new_oid = self.generate_id("ORDER_HEADER")
        new_header = orig_header.iloc[0].to_dict()
        new_header['order_id'] = new_oid
        new_header['status'] = 'Quote' # Default to Quote
        new_header['deposit_paid'] = 0.0
        new_header['balance_due'] = new_header['total_revenue'] # Reset balance since deposit is 0
        new_header['trip_start_date'] = datetime.now() # Reset dates to today/future? Or keep original? Let's keep original for now, user can edit.
        
        # 4. Create New Items
        new_items = []
        for _, item in orig_items.iterrows():
            n_item = item.to_dict()
            n_item.pop('item_id', None) # Remove old item ID
            n_item['order_id'] = new_oid
            new_items.append(n_item)
            
        # 5. Save
        if self.add_record("ORDER_HEADER", new_header):
            for itm in new_items:
                self.add_record("ORDER_ITEM", itm)
            return True, new_oid
            
        return False, "Failed to create new order header."
