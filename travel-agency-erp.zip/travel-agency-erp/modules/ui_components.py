import streamlit as st

def apply_theme():
    """
    Applies custom CSS for a modern, professional look.
    """
    st.markdown("""
    <style>
        /* Global Font & Background */
        .stApp {
            font-family: 'Inter', sans-serif;
        }
        
        /* Headers */
        h1, h2, h3 {
            font-weight: 700 !important;
            color: #2C3E50;
        }
        
        /* Metrics */
        .stMetric {
            background-color: #f8f9fa;
            border-radius: 10px;
            padding: 15px;
            border: 1px solid #e9ecef;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }
        
        /* Buttons */
        .stButton button {
            border-radius: 8px;
            font-weight: 600;
        }
        .stButton button[kind="primary"] {
            background-color: #4CAF50;
            border: none;
        }
        
        /* Containers */
        [data-testid="stForm"] {
            border-radius: 12px;
            padding: 20px;
            background-color: #ffffff;
            border: 1px solid #e0e0e0;
        }
        
        /* Tabs */
        .stTabs [data-baseweb="tab-list"] {
            gap: 20px;
        }
        .stTabs [data-baseweb="tab"] {
            height: 50px;
            white-space: pre-wrap;
            border-radius: 5px;
            padding-left: 20px;
            padding-right: 20px;
        }
        
        /* Sidebar */
        [data-testid="stSidebar"] {
            background-color: #f1f3f6;
            border-right: 1px solid #e0e0e0;
        }
        
        /* Card-like expanders */
        .streamlit-expanderHeader {
            background-color: #f8fbff;
            border-radius: 8px;
        }
    </style>
    """, unsafe_allow_html=True)

def render_header(title, icon, subtitle=None):
    """
    Renders a standard page header.
    """
    apply_theme()
    st.title(f"{icon} {title}")
    if subtitle:
        st.markdown(f"*{subtitle}*")
    st.divider()
