import pandas as pd
import plotly.express as px

class FinancialAnalyzer:
    def __init__(self, data_manager):
        self.dm = data_manager

    def get_kpis(self):
        orders = self.dm.load_data("ORDER_HEADER")
        
        if orders.empty:
            return {
                "revenue": 0.0,
                "cost": 0.0,
                "profit": 0.0,
                "outstanding": 0.0
            }
        
        # Filter out Quotes
        orders = orders[orders['status'] != 'Quote']
        
        # Ensure numeric types
        cols = ['total_revenue', 'total_cost', 'total_profit', 'balance_due']
        for col in cols:
            orders[col] = pd.to_numeric(orders[col], errors='coerce').fillna(0)

        return {
            "revenue": orders['total_revenue'].sum(),
            "cost": orders['total_cost'].sum(),
            "profit": orders['total_profit'].sum(),
            "outstanding": orders['balance_due'].sum()
        }

    def get_monthly_profit_chart(self):
        orders = self.dm.load_data("ORDER_HEADER")
        if orders.empty:
            return None
            
        orders = orders[orders['status'] != 'Quote']
        
        orders['trip_start_date'] = pd.to_datetime(orders['trip_start_date'])
        orders['Month'] = orders['trip_start_date'].dt.strftime('%Y-%m')
        orders['total_profit'] = pd.to_numeric(orders['total_profit'], errors='coerce').fillna(0)
        
        monthly_profit = orders.groupby('Month')['total_profit'].sum().reset_index()
        
        fig = px.bar(
            monthly_profit, 
            x='Month', 
            y='total_profit',
            title="Monthly Net Profit Trend",
            labels={'total_profit': 'Profit (LE)', 'Month': 'Month'},
            color='total_profit',
            color_continuous_scale='Greens'
        )
        return fig
