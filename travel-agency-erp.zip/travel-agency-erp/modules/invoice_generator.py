from fpdf import FPDF
import pandas as pd
import os
from datetime import datetime
from .data_manager import DataManager

class InvoiceGenerator:
    def __init__(self):
        self.dm = DataManager()
        
    def generate_pdf(self, order_id, customer_data, order_header, order_items, detailed=True, currency_code="EGP", exchange_rate=1.0):
        # Fetch Service Data for Name Lookup
        services_df = self.dm.load_data("SERVICE_PRODUCT")
        
        # Determine Symbols
        curr_symbol = "$" if currency_code in ["USD", "CAD", "AUD"] else ("¥" if currency_code in ["CNY", "JPY"] else ("€" if currency_code == "EUR" else ("£" if currency_code == "GBP" else f"{currency_code} ")))
        if currency_code == "EGP": curr_symbol = "EGP "
        
        pdf = FPDF()
        pdf.add_page()
        
        # --- HEADER ---
        pdf.set_font("Arial", "B", 20)
        pdf.set_text_color(50, 50, 100)
        pdf.cell(0, 10, "INVOICE", ln=True, align="R")
        pdf.ln(5)
        
        # Company Info
        pdf.set_font("Arial", "B", 10)
        pdf.set_text_color(0, 0, 0)
        pdf.cell(0, 5, "My Travel Agency Ltd.", ln=True)
        pdf.set_font("Arial", "", 10)
        pdf.cell(0, 5, "123 Adventure Blvd, Tourism City", ln=True)
        pdf.cell(0, 5, "support@mytravel.com | +1 234 567 890", ln=True)
        pdf.line(10, 40, 200, 40)
        pdf.ln(15)
        
        # --- INFO BLOCK ---
        col_w = 95
        
        # Left: Bill To
        pdf.set_font("Arial", "B", 10)
        pdf.cell(col_w, 5, "BILL TO:")
        pdf.cell(col_w, 5, "INVOICE DETAILS:", ln=True)
        
        pdf.set_font("Arial", "", 10)
        # Row 1
        pdf.cell(col_w, 5, f"{customer_data.get('name', 'Valued Customer')}")
        pdf.cell(col_w, 5, f"Invoice No: INV-{order_id}", ln=True)
        
        # Row 2
        pdf.cell(col_w, 5, f"Phone: {customer_data.get('phone', 'N/A')}")
        pdf.cell(col_w, 5, f"Date: {datetime.now().strftime('%Y-%m-%d')}", ln=True)
        
        # Row 3
        pdf.cell(col_w, 5, f"Email: {customer_data.get('email', 'N/A')}")
        pdf.cell(col_w, 5, f"Status: {order_header.get('status', 'Confirmed')}", ln=True)
        
        pdf.ln(15)
        
        # --- TABLE HEADER ---
        pdf.set_fill_color(240, 240, 240)
        pdf.set_font("Arial", "B", 10)
        if detailed:
            pdf.cell(90, 10, "Service Description", 1, 0, 'C', 1)
            pdf.cell(30, 10, "Quantity", 1, 0, 'C', 1)
            pdf.cell(35, 10, "Unit Price", 1, 0, 'C', 1)
            pdf.cell(35, 10, "Total", 1, 1, 'C', 1)
        else:
            pdf.cell(160, 10, "Service Description", 1, 0, 'C', 1)
            pdf.cell(30, 10, "Quantity", 1, 1, 'C', 1)
        
        # --- TABLE BODY ---
        pdf.set_font("Arial", "", 10)
        total_calc = 0.0
        
        for _, item in order_items.iterrows():
            qty = float(item.get('quantity', 0))
            price_egp = float(item.get('selling_price', 0))
            
            # Conversion
            price_disp = price_egp / exchange_rate
            line_total_disp = price_disp * qty
            total_calc += line_total_disp
            
            # Resolve Name
            svc_id = item.get('service_id')
            svc_name = f"Service Product ({svc_id})" # Default
            
            if not services_df.empty:
                match = services_df[services_df['service_id'] == svc_id]
                if not match.empty:
                    svc_name = match.iloc[0]['service_name']
            
            # Truncate long names
            max_len = 37 if detailed else 80
            if len(svc_name) > max_len:
                svc_name = svc_name[:max_len-3] + "..."
            
            if detailed:
                pdf.cell(90, 8, svc_name, 1)
                pdf.cell(30, 8, str(int(qty)), 1, 0, 'C')
                pdf.cell(35, 8, f"{curr_symbol}{price_disp:,.2f}", 1, 0, 'R')
                pdf.cell(35, 8, f"{curr_symbol}{line_total_disp:,.2f}", 1, 1, 'R')
            else:
                pdf.cell(160, 8, svc_name, 1)
                pdf.cell(30, 8, str(int(qty)), 1, 1, 'C')
            
        pdf.ln(5)
        
        # --- TOTALS ---
        # Draw total box
        x_start = 130
        
        pdf.set_x(x_start)
        pdf.cell(35, 8, "Subtotal:", 0, 0, 'R')
        pdf.cell(35, 8, f"{curr_symbol}{total_calc:,.2f}", 1, 1, 'R')
        
        deposit_egp = float(order_header.get('deposit_paid', 0))
        due_egp = float(order_header.get('balance_due', 0)) # Note: this might be slightly off due to rounding diffs but roughly ok
        
        # Recalculate totals closer to source to minimize drift, or just convert fields
        deposit_disp = deposit_egp / exchange_rate
        # Balance Due should be Total - Paid
        due_disp = total_calc - deposit_disp
        
        pdf.set_x(x_start)
        pdf.cell(35, 8, "Deposit Paid:", 0, 0, 'R')
        pdf.cell(35, 8, f"-{curr_symbol}{deposit_disp:,.2f}", 1, 1, 'R')
        
        pdf.set_font("Arial", "B", 11)
        pdf.set_x(x_start)
        pdf.set_fill_color(220, 230, 255)
        pdf.cell(35, 10, "BALANCE DUE:", 0, 0, 'R', 1)
        pdf.cell(35, 10, f"{curr_symbol}{due_disp:,.2f}", 1, 1, 'R', 1)
        
        # Exchange Rate Note
        if currency_code != "EGP":
            pdf.ln(5)
            pdf.set_font("Arial", "I", 8)
            pdf.set_x(x_start - 20)
            pdf.cell(90, 5, f"* Exchange Rate Used: 1 {currency_code} = {exchange_rate:.2f} EGP", 0, 1, 'R')
        
        # --- FOOTER ---
        pdf.set_y(-30)
        pdf.set_font("Arial", "I", 8)
        pdf.cell(0, 10, "Thank you for your business!", ln=True, align="C")
        pdf.cell(0, 5, "Please make payment within 30 days.", ln=True, align="C")
        
        return pdf.output(dest='S').encode('latin-1')

    def generate_itinerary_pdf(self, order_id, customer_data, order_header, order_items):
        # Fetch Service Data for Name Lookup
        services_df = self.dm.load_data("SERVICE_PRODUCT")
        
        pdf = FPDF()
        pdf.set_auto_page_break(auto=True, margin=15)
        pdf.add_page()
        
        # Color Palette
        PRIMARY_COLOR = (41, 128, 185)   # Blue
        ACCENT_COLOR = (243, 156, 18)    # Orange/Gold
        BG_COLOR = (245, 247, 250)       # Light Grey
        TEXT_COLOR = (44, 62, 80)        # Dark Blue/Grey
        
        # --- HEADER BANNER ---
        # Draw colored rectangle for header
        pdf.set_fill_color(*PRIMARY_COLOR)
        pdf.rect(0, 0, 210, 50, 'F')
        
        # Title
        pdf.set_font("Arial", "B", 26)
        pdf.set_text_color(255, 255, 255)
        pdf.set_y(15)
        pdf.cell(0, 10, "TRIP ITINERARY", ln=True, align="C")
        
        # Subtitle (Destination)
        dest = order_header.get('destination', 'Your Adventure')
        if not dest or dest == "nan": dest = "Your Journey"
        
        pdf.set_font("Arial", "", 14)
        pdf.cell(0, 10, f"Prepared for {customer_data.get('name', 'Valued Customer')}", ln=True, align="C")
        
        # --- TRIP SUMMARY CARD ---
        pdf.set_y(60)
        
        # Dates
        start_date = pd.to_datetime(order_header['trip_start_date']).strftime('%B %d, %Y')
        end_date = pd.to_datetime(order_header['trip_end_date']).strftime('%B %d, %Y')
        
        pdf.set_draw_color(200, 200, 200)
        pdf.set_fill_color(255, 255, 255)
        pdf.rect(10, 60, 190, 25, 'FD')
        
        pdf.set_y(65)
        pdf.set_text_color(*TEXT_COLOR)
        pdf.set_font("Arial", "B", 11)
        
        # Columns for Trip Info
        pdf.set_x(15)
        pdf.cell(60, 5, "TRAVELERS", ln=0)
        pdf.cell(70, 5, "DATES", ln=0)
        pdf.cell(50, 5, "ORDER REF", ln=1)
        
        pdf.set_font("Arial", "", 12)
        pdf.set_x(15)
        pax_raw = order_header.get('pax_count', 1)
        try:
             pax = int(pax_raw) if pd.notna(pax_raw) else 1
        except:
             pax = 1
        pdf.cell(60, 8, f"{pax} person{'s' if pax > 1 else ''}", ln=0)
        pdf.cell(70, 8, f"{start_date} - {end_date}", ln=0)
        pdf.cell(50, 8, f"#{order_id}", ln=1)
        
        pdf.ln(15)
        
        # --- ITINERARY DETAILS ---
        
        # Enrich Items
        if not order_items.empty and 'service_name' not in order_items.columns:
             if not services_df.empty:
                order_items = order_items.merge(
                    services_df[['service_id', 'service_name', 'service_type']],
                    on='service_id',
                    how='left'
                )
                order_items['service_name'] = order_items['service_name'].fillna("Unknown Service")
                order_items['service_type'] = order_items['service_type'].fillna("Other")
        
        # Sort Items
        order_items['day_number'] = order_items['day_number'].fillna(1).astype(int)
        order_items = order_items.sort_values(by=['day_number', 'start_time'])
        
        # Group by Day
        current_day = -1
        
        for _, item in order_items.iterrows():
            day = item['day_number']
            
            # Date Handling
            trip_start_dt = pd.to_datetime(order_header['trip_start_date'])
            day_date = trip_start_dt + pd.Timedelta(days=day-1)
            date_str = day_date.strftime('%A, %B %d')
            
            # --- New Day Section ---
            if day != current_day:
                pdf.ln(5)
                # Check for page break
                if pdf.get_y() > 250:
                    pdf.add_page()
                
                # Day Header Pill
                pdf.set_fill_color(*PRIMARY_COLOR)
                pdf.set_text_color(255, 255, 255)
                pdf.set_font("Arial", "B", 12)
                
                # Small rounded rect simulation (regular rect)
                pdf.cell(0, 10, f"   Day {day}  |  {date_str}", 0, 1, 'L', 1)
                pdf.ln(2)
                
                current_day = day
            
            # --- Event Item ---
            start_time = str(item.get('start_time', ''))
            if start_time.lower() == 'nan' or not start_time:
                start_time = ""
            else:
                start_time = start_time[:5]
            
            s_name = item.get('service_name', 'Activity')
            qty = int(item.get('quantity', 1))
            msg_qty = f"Qty: {qty}"
            
            # Conditionally show Qty
            s_type = str(item.get('service_type', 'Other'))
            if "Activity" not in s_type and "Other" not in s_type:
                 # Check specific logic if needed, user said: "unless it is an activity or other"
                 # So if it IS Activity or Other, show quantity. Else hide? 
                 # User: "remove the qty ... unless it is an activity or other"
                 # Means: Show if (Activity OR Other). Hide if (Car, Hotel, etc).
                  msg_qty = ""

            # Visual Timeline Line
            x_line = 18
            y_start = pdf.get_y()
            
            # Time Bubble
            if start_time:
                pdf.set_font("Arial", "B", 10)
                pdf.set_text_color(*PRIMARY_COLOR)
                pdf.set_x(10)
                pdf.cell(20, 8, start_time, 0, 0, 'R')
            
            # Content
            pdf.set_text_color(*TEXT_COLOR)
            pdf.set_font("Arial", "", 11)
            pdf.set_x(35)
            pdf.cell(140, 8, s_name, 0, 0)
            
            # Qty/Badge
            if msg_qty:
                pdf.set_font("Arial", "I", 9)
                pdf.set_text_color(128, 128, 128)
                pdf.cell(20, 8, msg_qty, 0, 1, 'R')
            else:
                pdf.ln(8)
            
            # Descriptions (Optional stub for future)
            # if 'description' in item:
            #    pdf.set_x(35)
            #    pdf.multi_cell(0, 5, item['description'])
            
            # Separator Line (Light)
            pdf.set_draw_color(240, 240, 240)
            pdf.line(35, pdf.get_y(), 200, pdf.get_y())
            
        # --- FOOTER SECTION ---
        pdf.set_y(-40)
        
        # Footer Divider
        pdf.set_draw_color(*PRIMARY_COLOR)
        pdf.set_line_width(0.5)
        pdf.line(10, pdf.get_y(), 200, pdf.get_y())
        pdf.ln(5)
        
        # Support Info
        pdf.set_text_color(*TEXT_COLOR)
        pdf.set_font("Arial", "B", 10)
        pdf.cell(0, 5, "Need Assistance?", ln=True, align="C")
        
        pdf.set_font("Arial", "", 9)
        pdf.cell(0, 5, "Support: +1 (555) 123-4567  |  Email: contact@mytravelagency.com", ln=True, align="C")
        pdf.cell(0, 5, "Emergency 24/7: +1 (555) 999-8888", ln=True, align="C")
        
        return pdf.output(dest='S').encode('latin-1')
