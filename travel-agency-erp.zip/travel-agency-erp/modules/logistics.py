from geopy.distance import geodesic
from datetime import timedelta

class LogisticsManager:
    @staticmethod
    def calculate_total_distance(locations_list):
        """
        Calculates total trip distance for a sequence of locations.
        locations_list: List of dicts [{'lat': float, 'lon': float, 'name': str}, ...]
        """
        if len(locations_list) < 2:
            return 0.0
            
        total_km = 0.0
        
        for i in range(len(locations_list) - 1):
            start = (locations_list[i]['lat'], locations_list[i]['lon'])
            end = (locations_list[i+1]['lat'], locations_list[i+1]['lon'])
            
            try:
                distance = geodesic(start, end).kilometers
                total_km += distance
            except Exception as e:
                print(f"Error calculating distance: {e}")
                
        return round(total_km, 2)

    @staticmethod
    def generate_itinerary_timeline(start_date, order_items):
        """
        Generates a structured timeline of the trip.
        start_date: datetime object
        order_items: list of dicts or DataFrame
        """
        import pandas as pd
        if isinstance(order_items, pd.DataFrame):
            items = order_items.to_dict('records')
        else:
            items = order_items

        # Group by Day
        timeline = {}
        for item in items:
            day = int(item.get('day_number', 1) or 1)
            if day not in timeline:
                timeline[day] = []
            timeline[day].append(item)

        # Sort days
        sorted_days = sorted(timeline.keys())
        
        result = []
        for day in sorted_days:
            date_str = (start_date + timedelta(days=day-1)).strftime('%Y-%m-%d (%A)')
            day_items = sorted(timeline[day], key=lambda x: x.get('start_time') if isinstance(x.get('start_time'), str) else '00:00')
            
            result.append({
                "day": day,
                "date": date_str,
                "items": day_items
            })
            
        return result
