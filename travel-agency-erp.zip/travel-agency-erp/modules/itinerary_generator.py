import pandas as pd
import re
from datetime import datetime, timedelta

class ItineraryGenerator:
    def __init__(self, data_manager):
        self.dm = data_manager
        
        # Default Durations (Hours)
        self.DURATION_MAP = {
            "Activity": 3,
            "Privat Tour": 4, # Common typo/variation
            "Guide": 8,
            "Car": 0, # Usually point-to-point, user defines
            "Transfer": 1,
            "Flight": 2,
            "Other": 1
        }

    def generate_from_order(self, order_id):
        """
        Generates itinerary entries from ORDER_ITEMS.
        Returns a list of dicts ready for ITINERARY table.
        Does NOT save to DB - allows preview/confirmation.
        """
        # 1. Load Data
        orders = self.dm.load_data("ORDER_HEADER")
        items = self.dm.load_data("ORDER_ITEM")
        services = self.dm.load_data("SERVICE_PRODUCT")
        
        if order_id not in orders['order_id'].values:
            return []
            
        order_row = orders[orders['order_id'] == order_id].iloc[0]
        trip_start = pd.to_datetime(order_row['trip_start_date'])
        
        order_items = items[items['order_id'] == order_id].copy()
        if order_items.empty:
            return []
            
        # 2. Process Items
        new_entries = []
        
        # Pre-scan for hotels to populate "Accommodation" for the whole day
        daily_hotels = {}
        for _, item in order_items.iterrows():
            svc_info = self._get_service_info(services, item['service_id'])
            if svc_info and svc_info['service_type'] == 'Hotel':
                day = int(item.get('day_number', 1))
                nights = int(item['quantity'])
                hotel_name = item['service_name']
                
                for i in range(nights):
                    current_day = day + i
                    daily_hotels[current_day] = hotel_name

        # Generate Entries
        for _, item in order_items.iterrows():
            svc_info = self._get_service_info(services, item['service_id'])
            if not svc_info:
                continue
                
            sType = svc_info['service_type']
            
            day_num = int(item.get('day_number', 1))
            entry_date = trip_start + timedelta(days=day_num - 1)
            
            start_time_str = str(item.get('start_time', '09:00'))
            try:
                start_dt = datetime.strptime(start_time_str, "%H:%M")
            except:
                start_dt = datetime.strptime("09:00", "%H:%M") # Fallback
            
            # Service Name safe retrieval (handle nan)
            svc_name = item.get('service_name')
            if pd.isna(svc_name) or str(svc_name) == 'nan':
                 svc_name = svc_info.get('service_name', 'Unknown Service')

            # Notes / Location Logic
            location_val = str(item.get('location', ''))
            
            # Split by newline or comma (handle various separators)
            # Filter out empty strings and 'nan'
            if location_val.lower() == 'nan':
                 sub_locations = [""]
            else:
                # Split by comma or newline
                raw_splits = re.split(r'[,\n]', location_val)
                sub_locations = [x.strip() for x in raw_splits if x.strip() and x.strip().lower() != 'nan']
                if not sub_locations:
                    sub_locations = [""] # Default to one pass if effectively empty (e.g. only ",,")

            # If Car Service and Location is present, put it in notes or even City Route?
            city_route = svc_info.get('city', '')
            
            # Distribute Duration
            total_duration_hours = self.DURATION_MAP.get(sType, 2)
            if sType == "Hotel":
                total_duration_hours = 0
            
            num_locs = len(sub_locations)
            chunk_duration = total_duration_hours / num_locs if num_locs > 0 else total_duration_hours
            
            current_start = start_dt
            
            for idx, loc in enumerate(sub_locations):
                # Calculate times for this chunk
                chunk_end = current_start + timedelta(hours=chunk_duration)
                
                s_str = current_start.strftime("%H:%M")
                e_str = chunk_end.strftime("%H:%M")
                
                # Build Notes
                notes_parts = []
                if loc:
                     notes_parts.append(f"Route: {loc}") # Clean text, no emoji
                
                # Create Entry
                entry = {
                    "order_id": order_id,
                    "date": entry_date,
                    "start_time": s_str,
                    "end_time": e_str,
                    "city_route": city_route,
                    "activity": svc_name, 
                    "notes": "\n".join(notes_parts),
                    "accommodation": daily_hotels.get(day_num, ""), # Auto-fill hotel
                    "linked_item_id": item['item_id'],
                    "is_locked": False
                }
                
                # If Hotel, maybe change activity text to "Check-in: Hotel Name"
                if sType == "Hotel":
                    entry['activity'] = f"🏨 Check-in: {svc_name}"
                    
                new_entries.append(entry)
                
                # Advance start time for next chunk
                current_start = chunk_end
            
        return new_entries

    def _get_service_info(self, services_df, service_id):
        match = services_df[services_df['service_id'] == service_id]
        if not match.empty:
            return match.iloc[0].to_dict()
        return None
