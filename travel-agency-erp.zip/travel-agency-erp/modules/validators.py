
def validate_customer(record):
    """
    Validates customer data.
    Returns (bool, message)
    """
    if not record.get("name") or len(record["name"].strip()) == 0:
        return False, "Customer Name is required."
    
    if not record.get("phone") and not record.get("email"):
        return False, "At least one contact method (Phone or Email) is required."
        
    return True, ""

def validate_vendor(record):
    """
    Validates vendor data.
    """
    if not record.get("vendor_name") or len(record["vendor_name"].strip()) == 0:
        return False, "Vendor Name is required."
    
    if not record.get("vendor_type"):
        return False, "Vendor Type is required."
        
    return True, ""

def validate_service(record):
    """
    Validates service product data.
    """
    if not record.get("service_name") or len(record["service_name"].strip()) == 0:
        return False, "Service Name is required."
        
    if not record.get("city") or len(record["city"].strip()) == 0:
        return False, "City is required."
        
    try:
        cost = float(record.get("default_base_cost", 0))
        if cost < 0:
            return False, "Base Cost cannot be negative."
    except ValueError:
        return False, "Invalid Base Cost value."
        
    return True, ""
