import pandas as pd
import os
import sys

DATA_DIR = os.path.join(os.getcwd(), "data")

def check_file(name, pk, numerics=[], dates=[]):
    path = os.path.join(DATA_DIR, f"{name}.xlsx")
    if not os.path.exists(path):
        print(f"[FAIL] {name}: File missing")
        return

    try:
        df = pd.read_excel(path)
        print(f"Checking {name} ({len(df)} rows)...")
        
        # 1. Check PK Unique
        if pk in df.columns:
            if not df[pk].is_unique:
                print(f"  [WARN] Duplicate Primary Keys found in {pk}")
            if df[pk].isnull().any():
                print(f"  [WARN] Null Primary Keys found in {pk}")
        else:
            print(f"  [FAIL] Missing Primary Key column: {pk}")

        # 2. Check Numerics
        for col in numerics:
            if col in df.columns:
                non_num = pd.to_numeric(df[col], errors='coerce').isnull().sum()
                if non_num > 0:
                    print(f"  [WARN] {non_num} non-numeric values in {col}")
        
        # 3. Check Dates
        for col in dates:
            if col in df.columns:
                non_date = pd.to_datetime(df[col], errors='coerce').isnull().sum()
                if non_date > 0:
                    print(f"  [WARN] {non_date} invalid dates in {col}")

        print(f"[OK] {name} check complete.\n")

    except Exception as e:
        print(f"[FAIL] Error reading {name}: {e}")

if __name__ == "__main__":
    check_file("CUSTOMER", pk="customer_id", numerics=["number_of_orders"])
    check_file("VENDOR", pk="vendor_id")
    check_file("SERVICE_PRODUCT", pk="service_id", numerics=["default_base_cost", "default_profit_margin_percent", "standard_selling_price"])
    check_file("LOCATION", pk="location_id", numerics=["latitude", "longitude"])
    check_file("ORDER_HEADER", pk="order_id", numerics=["total_cost", "total_revenue", "total_profit", "deposit_paid", "balance_due"], dates=["trip_start_date", "trip_end_date"])
    check_file("ORDER_ITEM", pk="item_id", numerics=["quantity", "actual_cost", "profit_margin_percent", "selling_price", "day_number"])
    check_file("PACKAGE_DEF", pk="package_id", numerics=["total_price"])
    check_file("PACKAGE_ITEMS", pk="package_id", numerics=["quantity"])
